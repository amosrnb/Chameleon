Status marker. `soft` for plan/state tags, `count` for unread numbers in nav, `label` for mono uppercase group headings.
```jsx
<Badge tone="accent">Business trial</Badge>
<Badge variant="count">3</Badge>
<Badge variant="label" tone="red">Overdue</Badge>
```
