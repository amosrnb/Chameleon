import React from "react";
import { Icon } from "../core/Icon.jsx";
export function PropertyChip({ icon, dot, label, empty, onClick }) {
  const [hov, setHov] = React.useState(false);
  return (
    <button type="button" onClick={onClick} onMouseEnter={() => setHov(true)} onMouseLeave={() => setHov(false)}
      style={{ height: 24, padding: label ? "0 8px" : "0 6px", display: "inline-flex", alignItems: "center", gap: 5, borderRadius: "var(--radius-pill)", border: "1px solid var(--border-default)", background: hov ? "var(--bg-hover)" : "transparent", color: empty ? "var(--text-tertiary)" : "var(--text-primary)", font: "var(--type-ui)", fontSize: 12, cursor: "pointer", whiteSpace: "nowrap" }}>
      {dot && <span style={{ width: 7, height: 7, borderRadius: 99, background: dot }} />}
      {icon && <Icon name={icon} size={13} color={empty ? "var(--text-tertiary)" : "var(--text-secondary)"} />}
      {label}
    </button>
  );
}
