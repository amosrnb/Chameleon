Empty view placeholder: large outline icon, short title, one-paragraph explanation, up to two actions.
```jsx
<EmptyState icon="boxes" title="Projects" description="Projects group issues toward one outcome." actions={<Button variant="primary">Create project</Button>} align="left" />
```
