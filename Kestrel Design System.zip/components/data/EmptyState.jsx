import React from "react";
import { Icon } from "../core/Icon.jsx";
export function EmptyState({ icon = "inbox", title, description, actions, align = "center" }) {
  const c = align === "center";
  return (
    <div style={{ maxWidth: 420, display: "flex", flexDirection: "column", alignItems: c ? "center" : "flex-start", textAlign: c ? "center" : "left", gap: 10 }}>
      <Icon name={icon} size={44} color="var(--text-tertiary)" style={{ marginBottom: 6 }} />
      {title && <div style={{ font: "var(--type-heading)", color: "var(--text-primary)" }}>{title}</div>}
      {description && <div style={{ font: "var(--type-body)", color: "var(--text-secondary)", textWrap: "pretty" }}>{description}</div>}
      {actions && <div style={{ display: "flex", gap: 8, marginTop: 8 }}>{actions}</div>}
    </div>
  );
}
