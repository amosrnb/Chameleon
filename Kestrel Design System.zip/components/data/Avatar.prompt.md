Avatar for people (round) and workspaces (`square`).
```jsx
<Avatar name="Max Mann" size={20} />
<Avatar name="Workspace" square size={24} color="var(--green-500)" />
```
