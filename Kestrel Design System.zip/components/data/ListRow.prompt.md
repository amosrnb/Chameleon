Dense item row for lists; id in mono, status icon, title, right-aligned property chips.
```jsx
<ListRow id="KES-23" statusIcon="circle-dashed" title="Design empty states" trailing={<PropertyChip dot="var(--violet-500)" label="Design" />} />
```
