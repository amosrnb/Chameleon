import * as React from "react";
/** Small status marker: soft pill, count bubble, or mono uppercase label. */
export interface BadgeProps { tone?: "neutral" | "accent" | "red" | "amber" | "green" | "blue" | "violet"; variant?: "soft" | "count" | "label"; children: React.ReactNode; }
export declare function Badge(props: BadgeProps): JSX.Element;
