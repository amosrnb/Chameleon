import * as React from "react";
/** Outlined pill showing one property of an item (status, priority, label, date). */
export interface PropertyChipProps { /** Lucide icon */ icon?: string; /** Color dot (labels) */ dot?: string; label?: string; /** Unset state: muted text */ empty?: boolean; onClick?: () => void; }
export declare function PropertyChip(props: PropertyChipProps): JSX.Element;
