import * as React from "react";
/** Dense 38px row for issue/item lists. */
export interface ListRowProps { /** Mono identifier, e.g. "KES-23" */ id?: string; statusIcon?: string; statusColor?: string; title: React.ReactNode; /** Muted trailing text, e.g. relative time */ meta?: string; /** Chips/avatars on the right */ trailing?: React.ReactNode; selected?: boolean; /** Nesting level for sub-items */ indent?: number; onClick?: () => void; }
export declare function ListRow(props: ListRowProps): JSX.Element;
