import React from "react";
const T = { neutral: ["var(--bg-selected)", "var(--text-secondary)"], accent: ["var(--accent-soft)", "var(--accent-text)"], red: ["var(--danger-soft)", "var(--danger)"], amber: ["var(--warning-soft)", "var(--warning)"], green: ["var(--success-soft)", "var(--success)"], blue: ["var(--info-soft)", "var(--info)"], violet: ["var(--violet-900)", "var(--violet-500)"] };
export function Badge({ tone = "neutral", variant = "soft", children }) {
  const [bg, fg] = T[tone];
  if (variant === "count") return <span style={{ minWidth: 18, height: 18, padding: "0 5px", borderRadius: 999, display: "inline-flex", alignItems: "center", justifyContent: "center", background: bg, color: fg, font: "var(--type-label)", fontSize: 11 }}>{children}</span>;
  if (variant === "label") return <span style={{ font: "var(--type-label)", letterSpacing: "var(--tracking-label)", textTransform: "uppercase", color: tone === "neutral" ? "var(--text-tertiary)" : fg }}>{children}</span>;
  return <span style={{ height: 20, padding: "0 7px", borderRadius: "var(--radius-xs)", display: "inline-flex", alignItems: "center", gap: 5, background: bg, color: fg, font: "var(--type-ui)", fontSize: 12 }}>{children}</span>;
}
