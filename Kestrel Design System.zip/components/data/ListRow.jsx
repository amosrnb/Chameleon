import React from "react";
import { Icon } from "../core/Icon.jsx";
export function ListRow({ id, statusIcon = "circle", statusColor = "var(--text-tertiary)", title, meta, trailing, selected, indent = 0, onClick }) {
  const [hov, setHov] = React.useState(false);
  return (
    <div onClick={onClick} onMouseEnter={() => setHov(true)} onMouseLeave={() => setHov(false)}
      style={{ height: "var(--h-row)", display: "flex", alignItems: "center", gap: 10, padding: "0 16px 0 " + (16 + indent * 20) + "px", borderBottom: "1px solid var(--border-subtle)", background: selected ? "var(--bg-selected)" : hov ? "var(--bg-hover)" : "transparent", cursor: "pointer" }}>
      {id && <span style={{ font: "var(--type-label)", color: "var(--text-tertiary)", width: 58, flexShrink: 0 }}>{id}</span>}
      <Icon name={statusIcon} size={14} color={statusColor} />
      <span style={{ flex: 1, minWidth: 0, font: "var(--type-ui)", color: "var(--text-primary)", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{title}</span>
      {meta && <span style={{ font: "var(--type-small)", color: "var(--text-tertiary)" }}>{meta}</span>}
      {trailing && <span style={{ display: "flex", alignItems: "center", gap: 6 }}>{trailing}</span>}
    </div>
  );
}
