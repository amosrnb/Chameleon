import * as React from "react";
/** Centered placeholder for empty views and unselected detail panes. */
export interface EmptyStateProps { icon?: string; title?: string; description?: string; actions?: React.ReactNode; align?: "center" | "left"; }
export declare function EmptyState(props: EmptyStateProps): JSX.Element;
