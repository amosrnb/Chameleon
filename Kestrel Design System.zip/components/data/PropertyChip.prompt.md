Outlined pill for item properties in rows and create dialogs; `empty` shows the unset placeholder.
```jsx
<PropertyChip icon="circle-dashed" label="Backlog" />
<PropertyChip dot="var(--violet-500)" label="Enhancement" />
<PropertyChip icon="calendar" label="Due date" empty />
```
