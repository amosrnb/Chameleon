import React from "react";
export function Avatar({ name = "", src, size = 20, color = "var(--kestrel-600)", square }) {
  const init = name.split(" ").map(s => s[0]).join("").slice(0, 2).toUpperCase();
  return <span title={name} style={{ width: size, height: size, flexShrink: 0, borderRadius: square ? Math.round(size * 0.25) : 999, background: src ? "center/cover url(" + src + ")" : color, color: "#fff", display: "inline-flex", alignItems: "center", justifyContent: "center", font: "var(--type-ui)", fontSize: Math.round(size * 0.42), fontWeight: 600 }}>{!src && init}</span>;
}
