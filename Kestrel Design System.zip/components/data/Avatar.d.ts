import * as React from "react";
/** Person or workspace avatar with initials fallback. */
export interface AvatarProps { name?: string; src?: string; size?: number; color?: string; /** Rounded square for workspaces/teams */ square?: boolean; }
export declare function Avatar(props: AvatarProps): JSX.Element;
