Popover list of commands; position it yourself (absolute) under its trigger.
```jsx
<Menu items={[{icon:"users",label:"Members"},{icon:"contact",label:"Teams"},{divider:true},{icon:"square-pen",label:"Customize sidebar"}]} />
```
Supports `heading`, `divider`, `kbd`, `checked`, `danger`.
