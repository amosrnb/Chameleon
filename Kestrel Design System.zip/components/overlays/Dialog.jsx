import React from "react";
import { IconButton } from "../actions/IconButton.jsx";
export function Dialog({ open = true, title, onClose, children, footer, width = 560, inline }) {
  if (!open) return null;
  const box = (
    <div role="dialog" style={{ width, maxWidth: "100%", maxHeight: "100%", display: "flex", flexDirection: "column", borderRadius: "var(--radius-lg)", background: "var(--bg-raised)", boxShadow: "var(--shadow-dialog)", overflow: "hidden" }}>
      <div style={{ display: "flex", alignItems: "center", gap: 8, padding: "16px 16px 8px 20px" }}>
        <div style={{ flex: 1, font: "var(--type-heading)", fontSize: 15, color: "var(--text-primary)" }}>{title}</div>
        {onClose && <IconButton icon="x" label="Close" onClick={onClose} />}
      </div>
      <div style={{ padding: "8px 20px 20px", overflow: "auto", flex: 1 }}>{children}</div>
      {footer && <div style={{ display: "flex", justifyContent: "flex-end", gap: 8, padding: "12px 16px", borderTop: "1px solid var(--border-subtle)" }}>{footer}</div>}
    </div>
  );
  if (inline) return box;
  return <div onClick={e => e.target === e.currentTarget && onClose && onClose()} style={{ position: "fixed", inset: 0, zIndex: 50, background: "var(--bg-overlay)", display: "flex", alignItems: "flex-start", justifyContent: "center", padding: "10vh 24px" }}>{box}</div>;
}
