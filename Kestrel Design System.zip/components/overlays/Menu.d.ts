import * as React from "react";
export interface MenuItem { label?: string; icon?: string; kbd?: string; checked?: boolean; danger?: boolean; divider?: boolean; heading?: string; onSelect?: () => void; }
/** Floating command list for dropdowns and context menus. */
export interface MenuProps { items: MenuItem[]; width?: number; }
export declare function Menu(props: MenuProps): JSX.Element;
