import * as React from "react";
/** Modal dialog with title, close button, body and optional footer. */
export interface DialogProps { open?: boolean; title?: React.ReactNode; onClose?: () => void; children?: React.ReactNode; footer?: React.ReactNode; width?: number; /** Render without overlay (for specimens/embedding) */ inline?: boolean; }
export declare function Dialog(props: DialogProps): JSX.Element | null;
