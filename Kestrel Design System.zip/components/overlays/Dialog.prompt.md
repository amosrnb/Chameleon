Modal for focused tasks (create item, settings). Sits near the top of the viewport, not centered.
```jsx
<Dialog title="Customize sidebar" onClose={close} footer={<Button variant="primary">Save</Button>}>…</Dialog>
```
