import * as React from "react";
/** Hover hint with optional shortcut. */
export interface TooltipProps { label: string; kbd?: string; children: React.ReactNode; side?: "top" | "bottom"; forceOpen?: boolean; }
export declare function Tooltip(props: TooltipProps): JSX.Element;
