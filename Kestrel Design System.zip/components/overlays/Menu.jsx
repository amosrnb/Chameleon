import React from "react";
import { Icon } from "../core/Icon.jsx";
function Item({ it }) {
  const [hov, setHov] = React.useState(false);
  return (
    <div onClick={it.onSelect} onMouseEnter={() => setHov(true)} onMouseLeave={() => setHov(false)}
      style={{ height: 30, display: "flex", alignItems: "center", gap: 8, padding: "0 8px", borderRadius: "var(--radius-sm)", background: hov ? "var(--bg-selected)" : "transparent", color: it.danger ? "var(--danger)" : "var(--text-primary)", font: "var(--type-ui)", cursor: "pointer", whiteSpace: "nowrap" }}>
      {it.icon && <Icon name={it.icon} size={15} color={it.danger ? "var(--danger)" : "var(--text-secondary)"} />}
      <span style={{ flex: 1 }}>{it.label}</span>
      {it.kbd && <span style={{ font: "var(--type-label)", color: "var(--text-tertiary)" }}>{it.kbd}</span>}
      {it.checked && <Icon name="check" size={14} color="var(--text-secondary)" />}
    </div>
  );
}
export function Menu({ items = [], width = 200 }) {
  return (
    <div role="menu" style={{ minWidth: width, padding: 4, borderRadius: "var(--radius-md)", background: "var(--bg-raised)", boxShadow: "var(--shadow-popover)", display: "flex", flexDirection: "column", gap: 1 }}>
      {items.map((it, i) => it.divider ? <div key={i} style={{ height: 1, background: "var(--border-subtle)", margin: "4px -4px" }} /> : it.heading ? <div key={i} style={{ padding: "6px 8px 2px", font: "var(--type-small)", color: "var(--text-tertiary)" }}>{it.heading}</div> : <Item key={i} it={it} />)}
    </div>
  );
}
