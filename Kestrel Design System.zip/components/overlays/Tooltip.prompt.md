Hover hint naming an icon-only control, with its shortcut.
```jsx
<Tooltip label="Filter" kbd="F"><IconButton icon="list-filter" label="Filter" /></Tooltip>
```
