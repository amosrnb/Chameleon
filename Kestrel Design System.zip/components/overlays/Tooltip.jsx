import React from "react";
export function Tooltip({ label, kbd, children, side = "bottom", forceOpen }) {
  const [hov, setHov] = React.useState(false);
  const show = forceOpen || hov;
  return (
    <span style={{ position: "relative", display: "inline-flex" }} onMouseEnter={() => setHov(true)} onMouseLeave={() => setHov(false)}>
      {children}
      {show && <span role="tooltip" style={{ position: "absolute", left: "50%", transform: "translateX(-50%)", [side === "top" ? "bottom" : "top"]: "calc(100% + 6px)", zIndex: 30, height: 24, padding: "0 8px", display: "inline-flex", alignItems: "center", gap: 6, whiteSpace: "nowrap", borderRadius: "var(--radius-sm)", background: "var(--bg-raised)", boxShadow: "var(--shadow-popover)", color: "var(--text-primary)", font: "var(--type-small)" }}>
        {label}{kbd && <span style={{ font: "var(--type-label)", color: "var(--text-tertiary)" }}>{kbd}</span>}
      </span>}
    </span>
  );
}
