import React from "react";
import { Icon } from "../core/Icon.jsx";
export function Input({ value, onChange, placeholder, icon, trailing, size = "md", invalid, disabled, style }) {
  const [foc, setFoc] = React.useState(false);
  const h = { sm: 24, md: 28, lg: 32 }[size];
  return (
    <label style={{ height: h, display: "flex", alignItems: "center", gap: 6, padding: "0 8px", borderRadius: "var(--radius-sm)", background: "var(--bg-control)", border: "1px solid " + (invalid ? "var(--danger)" : foc ? "var(--accent)" : "var(--border-default)"), opacity: disabled ? 0.5 : 1, transition: "border-color var(--dur-fast)", ...style }}>
      {icon && <Icon name={icon} size={14} color="var(--text-tertiary)" />}
      <input value={value} disabled={disabled} placeholder={placeholder} onChange={e => onChange && onChange(e.target.value)} onFocus={() => setFoc(true)} onBlur={() => setFoc(false)}
        style={{ flex: 1, minWidth: 0, border: 0, outline: 0, background: "transparent", color: "var(--text-primary)", font: "var(--type-body)" }} />
      {trailing}
    </label>
  );
}
