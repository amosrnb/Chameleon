import * as React from "react";
/** Boolean checkbox with optional label. */
export interface CheckboxProps { checked?: boolean; onChange?: (v: boolean) => void; label?: React.ReactNode; disabled?: boolean; }
export declare function Checkbox(props: CheckboxProps): JSX.Element;
