import React from "react";
import { Icon } from "../core/Icon.jsx";
export function Checkbox({ checked, onChange, label, disabled }) {
  return (
    <label style={{ display: "inline-flex", alignItems: "center", gap: 8, cursor: disabled ? "default" : "pointer", opacity: disabled ? 0.45 : 1, font: "var(--type-ui)", color: "var(--text-primary)" }}>
      <span onClick={() => !disabled && onChange && onChange(!checked)} style={{ width: 14, height: 14, borderRadius: 4, display: "inline-flex", alignItems: "center", justifyContent: "center", background: checked ? "var(--accent)" : "var(--bg-control)", border: "1px solid " + (checked ? "var(--accent)" : "var(--border-strong)"), color: "var(--on-accent)", transition: "background var(--dur-fast)" }}>
        {checked && <Icon name="check" size={11} />}
      </span>
      {label}
    </label>
  );
}
