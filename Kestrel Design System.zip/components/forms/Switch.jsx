import React from "react";
export function Switch({ checked, onChange, disabled }) {
  return (
    <button type="button" role="switch" aria-checked={!!checked} disabled={disabled} onClick={() => onChange && onChange(!checked)}
      style={{ width: 28, height: 16, padding: 2, border: 0, borderRadius: 999, background: checked ? "var(--accent)" : "var(--bg-selected)", boxShadow: "inset 0 0 0 1px var(--border-default)", cursor: "pointer", opacity: disabled ? 0.45 : 1, transition: "background var(--dur-base) var(--ease-out)" }}>
      <span style={{ display: "block", width: 12, height: 12, borderRadius: 999, background: checked ? "var(--on-accent)" : "var(--text-secondary)", transform: checked ? "translateX(12px)" : "none", transition: "transform var(--dur-base) var(--ease-out)" }} />
    </button>
  );
}
