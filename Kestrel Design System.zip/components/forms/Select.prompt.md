Dropdown for choosing one value; plain variant sits at the end of settings rows.
```jsx
<Select value="always" options={[{label:"Always show",value:"always"},{label:"Don't show",value:"never"}]} onChange={setV} />
```
