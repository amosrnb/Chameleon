import * as React from "react";
/** On/off toggle for settings that apply immediately. */
export interface SwitchProps { checked?: boolean; onChange?: (v: boolean) => void; disabled?: boolean; }
export declare function Switch(props: SwitchProps): JSX.Element;
