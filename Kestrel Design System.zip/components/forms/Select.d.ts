import * as React from "react";
/** Compact dropdown that shows the current value with a chevron and opens a Menu. */
export interface SelectProps { value: string; options: Array<string | { label: string; value: string }>; onChange?: (v: string) => void; /** plain = text trigger (settings rows); boxed = bordered control */ variant?: "plain" | "boxed"; style?: React.CSSProperties; }
export declare function Select(props: SelectProps): JSX.Element;
