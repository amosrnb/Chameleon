Checkbox for multi-select lists and settings.
```jsx
<Checkbox checked={on} onChange={setOn} label="Show sub-issues" />
```
