import * as React from "react";
/** Single-line text field. */
export interface InputProps { value?: string; onChange?: (v: string) => void; placeholder?: string; /** Leading Lucide icon */ icon?: string; /** Trailing node, e.g. <Kbd> */ trailing?: React.ReactNode; size?: "sm" | "md" | "lg"; invalid?: boolean; disabled?: boolean; style?: React.CSSProperties; }
export declare function Input(props: InputProps): JSX.Element;
