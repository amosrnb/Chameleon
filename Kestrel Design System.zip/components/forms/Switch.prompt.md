Toggle for settings that take effect immediately (no save button).
```jsx
<Switch checked={on} onChange={setOn} />
```
