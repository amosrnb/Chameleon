import React from "react";
import { Icon } from "../core/Icon.jsx";
import { Menu } from "../overlays/Menu.jsx";
export function Select({ value, options = [], onChange, variant = "plain", style }) {
  const [open, setOpen] = React.useState(false);
  const [hov, setHov] = React.useState(false);
  const cur = options.find(o => (o.value ?? o) === value);
  const label = cur ? (cur.label ?? cur) : value;
  return (
    <span style={{ position: "relative", display: "inline-flex", ...style }}>
      <button type="button" onClick={() => setOpen(!open)} onMouseEnter={() => setHov(true)} onMouseLeave={() => setHov(false)}
        style={{ height: 28, padding: "0 8px", display: "inline-flex", alignItems: "center", gap: 6, borderRadius: "var(--radius-sm)", border: variant === "boxed" ? "1px solid var(--border-default)" : "1px solid transparent", background: hov || open ? "var(--bg-hover)" : variant === "boxed" ? "var(--bg-control)" : "transparent", color: "var(--text-primary)", font: "var(--type-ui)", cursor: "pointer" }}>
        {label}<Icon name="chevron-down" size={14} color="var(--text-tertiary)" />
      </button>
      {open && <div style={{ position: "absolute", top: 32, right: 0, zIndex: 20 }}>
        <Menu items={options.map(o => ({ label: o.label ?? o, checked: (o.value ?? o) === value, onSelect: () => { onChange && onChange(o.value ?? o); setOpen(false); } }))} />
      </div>}
    </span>
  );
}
