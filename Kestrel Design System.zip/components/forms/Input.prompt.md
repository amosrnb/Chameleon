Single-line text field; use with `icon="search"` for search bars.
```jsx
<Input icon="search" placeholder="Search" trailing={<Kbd>⌘K</Kbd>} />
```
Focus turns the border accent; `invalid` turns it red.
