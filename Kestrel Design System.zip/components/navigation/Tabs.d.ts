import * as React from "react";
/** View switcher: pill (saved views/filters) or underline (page sections). */
export interface TabsProps { items: Array<string | { label: string; value: string }>; value: string; onChange?: (v: string) => void; variant?: "pill" | "underline"; }
export declare function Tabs(props: TabsProps): JSX.Element;
