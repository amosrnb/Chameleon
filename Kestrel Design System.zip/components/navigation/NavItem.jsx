import React from "react";
import { Icon } from "../core/Icon.jsx";
export function NavItem({ icon, emoji, label, active, count, indent = 0, muted, onClick, trailing }) {
  const [hov, setHov] = React.useState(false);
  return (
    <div onClick={onClick} onMouseEnter={() => setHov(true)} onMouseLeave={() => setHov(false)}
      style={{ height: "var(--h-nav-item)", display: "flex", alignItems: "center", gap: 8, padding: "0 8px", marginLeft: indent * 16, borderRadius: "var(--radius-sm)", background: active ? "var(--bg-selected)" : hov ? "var(--bg-hover)" : "transparent", color: active ? "var(--text-primary)" : muted ? "var(--text-tertiary)" : "var(--text-secondary)", font: "var(--type-ui)", cursor: "pointer", userSelect: "none" }}>
      {emoji ? <span style={{ width: 16, textAlign: "center", fontSize: 13 }}>{emoji}</span> : icon && <Icon name={icon} size={16} />}
      <span style={{ flex: 1, minWidth: 0, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap", fontWeight: active ? 600 : 500 }}>{label}</span>
      {hov && trailing}
      {count != null && <span style={{ font: "var(--type-label)", color: "var(--text-tertiary)" }}>{count}</span>}
    </div>
  );
}
