Collapsible sidebar group; the chevron appears on hover and when collapsed.
```jsx
<NavSection label="Workspace"><NavItem icon="box" label="Projects" /></NavSection>
```
