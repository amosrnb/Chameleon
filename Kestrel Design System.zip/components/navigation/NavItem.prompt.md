Sidebar row; active state is a filled gray pill with semibold label.
```jsx
<NavItem icon="inbox" label="Inbox" active count={3} />
<NavItem icon="layers" label="Views" indent={1} />
```
