import React from "react";
export function Tabs({ items = [], value, onChange, variant = "pill" }) {
  return (
    <div style={{ display: "flex", alignItems: "center", gap: variant === "pill" ? 4 : 16, borderBottom: variant === "underline" ? "1px solid var(--border-subtle)" : "none" }}>
      {items.map(it => {
        const v = it.value ?? it, l = it.label ?? it, on = v === value;
        return variant === "pill"
          ? <button key={v} type="button" onClick={() => onChange && onChange(v)} style={{ height: 26, padding: "0 10px", border: on ? "1px solid var(--border-default)" : "1px solid transparent", borderRadius: "var(--radius-pill)", background: on ? "var(--bg-selected)" : "transparent", color: on ? "var(--text-primary)" : "var(--text-secondary)", font: "var(--type-ui)", fontSize: 12, cursor: "pointer" }}>{l}</button>
          : <button key={v} type="button" onClick={() => onChange && onChange(v)} style={{ height: 36, padding: 0, border: 0, borderBottom: "2px solid " + (on ? "var(--text-primary)" : "transparent"), marginBottom: -1, background: "transparent", color: on ? "var(--text-primary)" : "var(--text-secondary)", font: "var(--type-ui)", cursor: "pointer" }}>{l}</button>;
      })}
    </div>
  );
}
