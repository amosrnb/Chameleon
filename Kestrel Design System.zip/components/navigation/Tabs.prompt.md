Switch between views. Pill for view filters under a header, underline for project sections.
```jsx
<Tabs items={["All issues","Active","Backlog"]} value={v} onChange={setV} />
```
