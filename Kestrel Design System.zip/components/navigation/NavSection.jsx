import React from "react";
import { Icon } from "../core/Icon.jsx";
export function NavSection({ label, defaultOpen = true, children, action }) {
  const [open, setOpen] = React.useState(defaultOpen);
  const [hov, setHov] = React.useState(false);
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 1 }} onMouseEnter={() => setHov(true)} onMouseLeave={() => setHov(false)}>
      <div onClick={() => setOpen(!open)} style={{ height: 26, display: "flex", alignItems: "center", gap: 4, padding: "0 8px", color: "var(--text-tertiary)", font: "var(--type-ui)", fontSize: 12, cursor: "pointer", userSelect: "none" }}>
        <span>{label}</span>
        <Icon name="chevron-right" size={12} style={{ transform: open ? "rotate(90deg)" : "none", transition: "transform var(--dur-base) var(--ease-out)", opacity: hov || !open ? 1 : 0 }} />
        <span style={{ flex: 1 }} />
        {hov && action}
      </div>
      {open && children}
    </div>
  );
}
