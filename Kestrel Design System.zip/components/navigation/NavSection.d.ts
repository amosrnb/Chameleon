import * as React from "react";
/** Collapsible sidebar group with a muted heading. */
export interface NavSectionProps { label: string; defaultOpen?: boolean; children?: React.ReactNode; /** Hover action on the heading, e.g. add button */ action?: React.ReactNode; }
export declare function NavSection(props: NavSectionProps): JSX.Element;
