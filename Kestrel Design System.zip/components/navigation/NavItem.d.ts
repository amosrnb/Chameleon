import * as React from "react";
/**
 * Sidebar navigation row.
 * @startingPoint section="Navigation" subtitle="Sidebar with sections and nav items" viewport="700x360"
 */
export interface NavItemProps { /** Lucide icon */ icon?: string; /** Emoji avatar for user-named projects */ emoji?: string; label: string; active?: boolean; count?: number; /** Nesting level (16px each) */ indent?: number; /** Hidden/disabled look */ muted?: boolean; /** Shown on hover, e.g. an IconButton */ trailing?: React.ReactNode; onClick?: () => void; }
export declare function NavItem(props: NavItemProps): JSX.Element;
