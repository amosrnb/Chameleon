import * as React from "react";
/** Lucide glyph from the icon font. */
export interface IconProps { /** Lucide icon name, e.g. "inbox" */ name: string; /** px, default 16 */ size?: number; color?: string; style?: React.CSSProperties; }
export declare function Icon(props: IconProps): JSX.Element;
