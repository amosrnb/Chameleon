import React from "react";
export function Icon({ name, size = 16, color, style }) {
  return <i className={"icon-" + name} aria-hidden="true" style={{ fontSize: size, width: size, height: size, lineHeight: 1, display: "inline-flex", alignItems: "center", justifyContent: "center", flexShrink: 0, color, ...style }} />;
}
