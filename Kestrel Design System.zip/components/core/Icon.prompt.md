Renders a Lucide icon (icon font) at a given size; use for every glyph in the UI.
```jsx
<Icon name="inbox" size={16} color="var(--text-secondary)" />
```
Names follow lucide.dev. Default 16px in nav and rows, 14px inside chips/small buttons.
