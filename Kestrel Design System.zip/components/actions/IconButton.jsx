import React from "react";
import { Icon } from "../core/Icon.jsx";
export function IconButton({ icon, size = "md", variant = "ghost", active, label, onClick, style }) {
  const [hov, setHov] = React.useState(false);
  const d = { sm: 24, md: 28, lg: 32 }[size];
  const round = variant === "round";
  return (
    <button type="button" title={label} aria-label={label} onClick={onClick} onMouseEnter={() => setHov(true)} onMouseLeave={() => setHov(false)}
      style={{ width: d, height: d, padding: 0, display: "inline-flex", alignItems: "center", justifyContent: "center", border: round ? "1px solid var(--border-subtle)" : "none", borderRadius: round ? "var(--radius-pill)" : "var(--radius-sm)", background: active ? "var(--bg-selected)" : hov ? "var(--bg-hover)" : round ? "var(--bg-control)" : "transparent", color: active || hov ? "var(--text-primary)" : "var(--text-secondary)", cursor: "pointer", transition: "background var(--dur-fast)", ...style }}>
      <Icon name={icon} size={size === "sm" ? 14 : 16} />
    </button>
  );
}
