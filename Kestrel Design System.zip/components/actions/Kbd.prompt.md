Keyboard key cap for shortcut hints in menus, tooltips and help.
```jsx
<Kbd>⌘</Kbd><Kbd>K</Kbd>
```
