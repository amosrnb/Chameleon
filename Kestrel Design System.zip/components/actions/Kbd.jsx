import React from "react";
export function Kbd({ children }) {
  return <kbd style={{ font: "var(--type-label)", fontSize: 11, minWidth: 18, height: 18, padding: "0 5px", display: "inline-flex", alignItems: "center", justifyContent: "center", borderRadius: 4, border: "1px solid var(--border-default)", background: "var(--bg-control)", color: "var(--text-secondary)" }}>{children}</kbd>;
}
