Command button; use primary once per view for the main action, secondary for everything else, ghost in toolbars.
```jsx
<Button variant="primary" icon="plus" kbd={["N","P"]}>New project</Button>
<Button>Cancel</Button>
```
Sizes sm 24 / md 28 / lg 32. `kbd` renders inline shortcut caps.
