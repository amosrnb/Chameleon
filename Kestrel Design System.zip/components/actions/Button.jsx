import React from "react";
import { Icon } from "../core/Icon.jsx";
const H = { sm: 24, md: 28, lg: 32 };
export function Button({ variant = "secondary", size = "md", icon, kbd, disabled, children, onClick, style }) {
  const [hov, setHov] = React.useState(false);
  const v = {
    primary: { bg: "var(--accent)", bgH: "var(--accent-hover)", fg: "var(--on-accent)", bd: "transparent" },
    secondary: { bg: "var(--bg-control)", bgH: "var(--bg-control-hover)", fg: "var(--text-primary)", bd: "var(--border-default)" },
    ghost: { bg: "transparent", bgH: "var(--bg-hover)", fg: "var(--text-secondary)", bd: "transparent" },
    danger: { bg: "var(--danger-soft)", bgH: "var(--danger)", fg: "var(--danger)", bd: "transparent" },
  }[variant];
  const fg = variant === "danger" && hov && !disabled ? "#fff" : (variant === "ghost" && hov ? "var(--text-primary)" : v.fg);
  return (
    <button type="button" disabled={disabled} onClick={onClick} onMouseEnter={() => setHov(true)} onMouseLeave={() => setHov(false)}
      style={{ height: H[size], padding: size === "sm" ? "0 8px" : "0 12px", display: "inline-flex", alignItems: "center", gap: 6, border: "1px solid " + v.bd, borderRadius: "var(--radius-sm)", background: hov && !disabled ? v.bgH : v.bg, color: fg, font: "var(--type-ui)", fontSize: size === "sm" ? 12 : 13, cursor: disabled ? "default" : "pointer", opacity: disabled ? 0.45 : 1, transition: "background var(--dur-fast), color var(--dur-fast)", whiteSpace: "nowrap", ...style }}>
      {icon && <Icon name={icon} size={size === "sm" ? 13 : 14} />}
      {children}
      {kbd && <span style={{ display: "inline-flex", gap: 3, marginLeft: 2 }}>{[].concat(kbd).map((k, i) => <span key={i} style={{ font: "var(--type-label)", fontSize: 10, minWidth: 16, height: 16, padding: "0 4px", borderRadius: 4, display: "inline-flex", alignItems: "center", justifyContent: "center", background: variant === "primary" ? "rgba(0,0,0,.14)" : "var(--white-a7)" }}>{k}</span>)}</span>}
    </button>
  );
}
