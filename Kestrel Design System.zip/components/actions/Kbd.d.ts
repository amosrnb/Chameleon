import * as React from "react";
/** Keyboard key cap. */
export interface KbdProps { children: React.ReactNode; }
export declare function Kbd(props: KbdProps): JSX.Element;
