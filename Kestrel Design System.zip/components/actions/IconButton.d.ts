import * as React from "react";
/** Square or round icon-only button for toolbars and headers. */
export interface IconButtonProps { icon: string; size?: "sm" | "md" | "lg"; variant?: "ghost" | "round"; active?: boolean; /** Accessible label + tooltip */ label: string; onClick?: () => void; style?: React.CSSProperties; }
export declare function IconButton(props: IconButtonProps): JSX.Element;
