Icon-only button for toolbar actions (filter, display options, more); always pass `label`.
```jsx
<IconButton icon="list-filter" label="Filter" />
<IconButton icon="square-pen" variant="round" label="New issue" />
```
`round` is used for the sidebar compose button.
