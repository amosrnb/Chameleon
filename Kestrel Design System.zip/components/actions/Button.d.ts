import * as React from "react";
/**
 * Text button for commands.
 * @startingPoint section="Actions" subtitle="Primary, secondary, ghost and danger buttons" viewport="700x220"
 */
export interface ButtonProps { variant?: "primary" | "secondary" | "ghost" | "danger"; size?: "sm" | "md" | "lg"; /** Lucide icon name shown before the label */ icon?: string; /** Shortcut hint keys, e.g. ["N","P"] */ kbd?: string | string[]; disabled?: boolean; children?: React.ReactNode; onClick?: () => void; style?: React.CSSProperties; }
export declare function Button(props: ButtonProps): JSX.Element;
