# Kestrel Design System

Kestrel is an original design system for compact, keyboard-first work software: issue trackers, inboxes, project tools. It is dark-first, dense, and organised around a persistent sidebar with clear sections.

## Sources
- 24 reference screenshots in `uploads/` (Screenshot 2026-10-13 090123 … 125215). They show third-party project-management apps (dark sidebar + inset content panel, grouped issue lists, property pills, empty states, settings dialogs, a light variant with mono uppercase group labels).
- Brief: "clean, compact, nice modern software with clear navigation".
- No codebase, Figma, logo, or font files were provided. The screenshots were used for **qualities only** (density, layout structure, interaction patterns). Kestrel's name, colours, type, wordmark and copy are original and not tied to any company in the references.

## Products
- **Workspace app** (`ui_kits/app/`) — sidebar navigation, Issues list, Inbox, Projects, Create issue dialog.

## Content fundamentals
- **Voice:** plain, calm, matter-of-fact. Describe what a thing is or does; no hype, no exclamation marks.
- **Person:** address the user as "you" sparingly; most UI copy is imperative or nominal ("New issue", "Mark all read"). Use "Your teams" / "My issues" for personal scopes.
- **Casing:** Sentence case everywhere ("Create project", "Customize sidebar"). Mono group labels are UPPERCASE ("OVERDUE", "THIS WEEK"). IDs are uppercase prefix + number: `KES-128`.
- **Length:** labels 1–3 words. Empty-state descriptions are one or two sentences that define the object: "Projects are larger units of work with one clear outcome…".
- **Placeholders** end with an ellipsis: "Add a description…", "Issue title".
- **Empty/neutral states** state the fact: "No notification selected", "Nothing here".
- **Time:** compact relative ("12m", "4h"), short dates ("14 Oct").
- **Shortcuts** appear next to commands ("Create project N P", "Filter F").
- **Emoji:** never in system copy. Users may give projects/teams an emoji as an avatar; render it in place of the icon.

## Visual foundations
- **Colour:** near-black neutral ramp (`--gray-0` #08090a app → `--gray-6`). Four ink levels for text. One accent, a muted *Kestrel slate* (#7d89aa), low-saturation for maximum calm, reserved for the primary action, focus, unread dots and toggles — never large fills. Semantic red/amber/green/blue plus violet for labels, each with a dark "soft" tint for badges. Light theme via `[data-theme="light"]`.
- **Type:** Geist (sans) for everything, Geist Mono for IDs, counts, shortcut caps and uppercase group labels. 13px is the base UI size; 12px small; 11px mono labels with +0.08em tracking; titles 20px; display 28px with −0.02em.
- **Spacing:** 2px base with tight steps (2/4/6/8/10/12/16/20/24/32/40). Fixed heights: controls 24/28/32, nav items 30, list rows 38, panel headers 48.
- **Layout:** fixed 232px sidebar sitting directly on `--bg-app`; content lives in one inset panel (`--bg-panel`, 8px gutter, 8px radius, hairline ring). Split views use a 360px list pane + detail. Headers are 48px with title left, icon tools right.
- **Backgrounds:** flat colour only. No gradients, textures, photos, or illustrations in chrome.
- **Borders:** 1px translucent white (`--border-subtle` 7%, `--border-default` 10%, `--border-strong` 16%). Rows are separated by subtle hairlines.
- **Shadows:** elevation = hairline ring + soft black drop. Panel: ring only. Popover: ring + 0 10px 28px. Dialog: ring + 0 24px 64px. No inner shadows.
- **Corner radii:** 4 (badges, kbd), 6 (buttons, inputs, nav items, menu items), 8 (panels, popovers), 12 (dialogs), pill (property chips, pill tabs, round icon buttons).
- **Cards:** rare. Grouped settings sit in a `--bg-raised` box with 1px border and 8px radius; otherwise content is rows, not cards.
- **Hover:** background steps up one gray (`--bg-hover`), text goes from secondary to primary. No colour shifts on neutrals, no underlines except links.
- **Active/selected:** filled `--bg-selected` pill + semibold label (nav), or full-row fill (lists).
- **Press:** no shrink; state change is instant.
- **Focus:** 2px accent ring offset by 2px (`--focus-ring`); inputs swap border to accent.
- **Motion:** short and functional — 100ms for hover colour, 160ms `cubic-bezier(.2,.8,.2,1)` for chevrons, toggles and popovers. No bounces, no page transitions.
- **Transparency/blur:** only the modal scrim (`rgba(0,0,0,.6)`). No glass blur.
- **Imagery:** none in chrome. Avatars are initials on muted fills.
- **Dialogs** sit ~10vh from the top, not dead centre.

## Iconography
- **Lucide** (outline, 2px stroke, rounded joins) via the `lucide-static@0.460.0` icon font from unpkg, imported in `tokens/fonts.css`. Use through `<Icon name="inbox" />`.
- 16px in nav and rows, 13–14px inside chips and small buttons, 44px for empty-state glyphs (tertiary colour).
- Icons are always monochrome, coloured with text tokens; status icons (circle, circle-dashed, circle-dot, circle-check) take semantic colours.
- No emoji or unicode glyphs as icons, except "›" breadcrumb separators and "⌘" in shortcut caps.
- Substitution flag: no icon assets were supplied; Lucide was chosen as the closest match to the outline style in the references.

## Brand
- No logo was supplied. The wordmark is plain lowercase "kestrel" in Geist Semibold (−0.03em). Replace when a real mark exists.

## Fonts
- Geist and Geist Mono load from Google Fonts (`tokens/fonts.css`). No local font files were provided; send licensed files if you want them self-hosted.

## Index
- `styles.css` — entry; imports `tokens/fonts.css`, `colors.css`, `typography.css`, `spacing.css`, `base.css`
- `guidelines/` — foundation specimen cards (colours, type, spacing, radii, elevation, wordmark)
- `components/` — React primitives, each with `.jsx`, `.d.ts`, `.prompt.md` and one card per folder
- `ui_kits/app/` — workspace app click-through
- `thumbnail.html`, `SKILL.md`

## Components
- core: Icon
- actions: Button, IconButton, Kbd
- forms: Input, Checkbox, Switch, Select
- data: Badge, PropertyChip, Avatar, ListRow, EmptyState
- navigation: NavItem, NavSection, Tabs
- overlays: Menu, Dialog, Tooltip

### Intentional additions
- **Icon** — wrapper over the Lucide icon font so every glyph is sized and coloured consistently.
- No source component inventory existed, so the full set above is authored from scratch, sized to the patterns seen in the references.
