/* @ds-bundle: {"format":4,"namespace":"KestrelDesignSystem_3eefff","components":[{"name":"Button","sourcePath":"components/actions/Button.jsx"},{"name":"IconButton","sourcePath":"components/actions/IconButton.jsx"},{"name":"Kbd","sourcePath":"components/actions/Kbd.jsx"},{"name":"Icon","sourcePath":"components/core/Icon.jsx"},{"name":"Avatar","sourcePath":"components/data/Avatar.jsx"},{"name":"Badge","sourcePath":"components/data/Badge.jsx"},{"name":"EmptyState","sourcePath":"components/data/EmptyState.jsx"},{"name":"ListRow","sourcePath":"components/data/ListRow.jsx"},{"name":"PropertyChip","sourcePath":"components/data/PropertyChip.jsx"},{"name":"Checkbox","sourcePath":"components/forms/Checkbox.jsx"},{"name":"Input","sourcePath":"components/forms/Input.jsx"},{"name":"Select","sourcePath":"components/forms/Select.jsx"},{"name":"Switch","sourcePath":"components/forms/Switch.jsx"},{"name":"NavItem","sourcePath":"components/navigation/NavItem.jsx"},{"name":"NavSection","sourcePath":"components/navigation/NavSection.jsx"},{"name":"Tabs","sourcePath":"components/navigation/Tabs.jsx"},{"name":"Dialog","sourcePath":"components/overlays/Dialog.jsx"},{"name":"Menu","sourcePath":"components/overlays/Menu.jsx"},{"name":"Tooltip","sourcePath":"components/overlays/Tooltip.jsx"}],"sourceHashes":{"components/actions/Button.jsx":"d0469f104d2f","components/actions/IconButton.jsx":"58b7274b7d5f","components/actions/Kbd.jsx":"7ac4bba8a3c3","components/core/Icon.jsx":"40365533a2ed","components/data/Avatar.jsx":"7419bb9999de","components/data/Badge.jsx":"e89a8d0ff870","components/data/EmptyState.jsx":"f5c7e405547d","components/data/ListRow.jsx":"8ebe9da3cb4c","components/data/PropertyChip.jsx":"67c6c11cdf9d","components/forms/Checkbox.jsx":"c6eba513dc0c","components/forms/Input.jsx":"5ace84b57236","components/forms/Select.jsx":"a8a950258b77","components/forms/Switch.jsx":"b1c81fdd0d43","components/navigation/NavItem.jsx":"1399b76b043e","components/navigation/NavSection.jsx":"52419fb02499","components/navigation/Tabs.jsx":"d730dc8c293b","components/overlays/Dialog.jsx":"927787966b2e","components/overlays/Menu.jsx":"88f779069c96","components/overlays/Tooltip.jsx":"9d5674544595","ui_kits/app/CreateDialog.jsx":"5b5a75fa5327","ui_kits/app/InboxView.jsx":"2ed29f7da314","ui_kits/app/IssuesView.jsx":"062cb2aadfc1","ui_kits/app/PanelHeader.jsx":"a8abb1c6df8d","ui_kits/app/ProjectsView.jsx":"0e1b8a2a35ed","ui_kits/app/Sidebar.jsx":"06d72a5bf647","ui_kits/app/data.js":"b5af88a26223"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.KestrelDesignSystem_3eefff = window.KestrelDesignSystem_3eefff || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/actions/Kbd.jsx
try { (() => {
function Kbd({
  children
}) {
  return /*#__PURE__*/React.createElement("kbd", {
    style: {
      font: "var(--type-label)",
      fontSize: 11,
      minWidth: 18,
      height: 18,
      padding: "0 5px",
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      borderRadius: 4,
      border: "1px solid var(--border-default)",
      background: "var(--bg-control)",
      color: "var(--text-secondary)"
    }
  }, children);
}
Object.assign(__ds_scope, { Kbd });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/actions/Kbd.jsx", error: String((e && e.message) || e) }); }

// components/core/Icon.jsx
try { (() => {
function Icon({
  name,
  size = 16,
  color,
  style
}) {
  return /*#__PURE__*/React.createElement("i", {
    className: "icon-" + name,
    "aria-hidden": "true",
    style: {
      fontSize: size,
      width: size,
      height: size,
      lineHeight: 1,
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      flexShrink: 0,
      color,
      ...style
    }
  });
}
Object.assign(__ds_scope, { Icon });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Icon.jsx", error: String((e && e.message) || e) }); }

// components/actions/Button.jsx
try { (() => {
const H = {
  sm: 24,
  md: 28,
  lg: 32
};
function Button({
  variant = "secondary",
  size = "md",
  icon,
  kbd,
  disabled,
  children,
  onClick,
  style
}) {
  const [hov, setHov] = React.useState(false);
  const v = {
    primary: {
      bg: "var(--accent)",
      bgH: "var(--accent-hover)",
      fg: "var(--on-accent)",
      bd: "transparent"
    },
    secondary: {
      bg: "var(--bg-control)",
      bgH: "var(--bg-control-hover)",
      fg: "var(--text-primary)",
      bd: "var(--border-default)"
    },
    ghost: {
      bg: "transparent",
      bgH: "var(--bg-hover)",
      fg: "var(--text-secondary)",
      bd: "transparent"
    },
    danger: {
      bg: "var(--danger-soft)",
      bgH: "var(--danger)",
      fg: "var(--danger)",
      bd: "transparent"
    }
  }[variant];
  const fg = variant === "danger" && hov && !disabled ? "#fff" : variant === "ghost" && hov ? "var(--text-primary)" : v.fg;
  return /*#__PURE__*/React.createElement("button", {
    type: "button",
    disabled: disabled,
    onClick: onClick,
    onMouseEnter: () => setHov(true),
    onMouseLeave: () => setHov(false),
    style: {
      height: H[size],
      padding: size === "sm" ? "0 8px" : "0 12px",
      display: "inline-flex",
      alignItems: "center",
      gap: 6,
      border: "1px solid " + v.bd,
      borderRadius: "var(--radius-sm)",
      background: hov && !disabled ? v.bgH : v.bg,
      color: fg,
      font: "var(--type-ui)",
      fontSize: size === "sm" ? 12 : 13,
      cursor: disabled ? "default" : "pointer",
      opacity: disabled ? 0.45 : 1,
      transition: "background var(--dur-fast), color var(--dur-fast)",
      whiteSpace: "nowrap",
      ...style
    }
  }, icon && /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: icon,
    size: size === "sm" ? 13 : 14
  }), children, kbd && /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex",
      gap: 3,
      marginLeft: 2
    }
  }, [].concat(kbd).map((k, i) => /*#__PURE__*/React.createElement("span", {
    key: i,
    style: {
      font: "var(--type-label)",
      fontSize: 10,
      minWidth: 16,
      height: 16,
      padding: "0 4px",
      borderRadius: 4,
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      background: variant === "primary" ? "rgba(0,0,0,.14)" : "var(--white-a7)"
    }
  }, k))));
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/actions/Button.jsx", error: String((e && e.message) || e) }); }

// components/actions/IconButton.jsx
try { (() => {
function IconButton({
  icon,
  size = "md",
  variant = "ghost",
  active,
  label,
  onClick,
  style
}) {
  const [hov, setHov] = React.useState(false);
  const d = {
    sm: 24,
    md: 28,
    lg: 32
  }[size];
  const round = variant === "round";
  return /*#__PURE__*/React.createElement("button", {
    type: "button",
    title: label,
    "aria-label": label,
    onClick: onClick,
    onMouseEnter: () => setHov(true),
    onMouseLeave: () => setHov(false),
    style: {
      width: d,
      height: d,
      padding: 0,
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      border: round ? "1px solid var(--border-subtle)" : "none",
      borderRadius: round ? "var(--radius-pill)" : "var(--radius-sm)",
      background: active ? "var(--bg-selected)" : hov ? "var(--bg-hover)" : round ? "var(--bg-control)" : "transparent",
      color: active || hov ? "var(--text-primary)" : "var(--text-secondary)",
      cursor: "pointer",
      transition: "background var(--dur-fast)",
      ...style
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: icon,
    size: size === "sm" ? 14 : 16
  }));
}
Object.assign(__ds_scope, { IconButton });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/actions/IconButton.jsx", error: String((e && e.message) || e) }); }

// components/data/Avatar.jsx
try { (() => {
function Avatar({
  name = "",
  src,
  size = 20,
  color = "var(--kestrel-600)",
  square
}) {
  const init = name.split(" ").map(s => s[0]).join("").slice(0, 2).toUpperCase();
  return /*#__PURE__*/React.createElement("span", {
    title: name,
    style: {
      width: size,
      height: size,
      flexShrink: 0,
      borderRadius: square ? Math.round(size * 0.25) : 999,
      background: src ? "center/cover url(" + src + ")" : color,
      color: "#fff",
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      font: "var(--type-ui)",
      fontSize: Math.round(size * 0.42),
      fontWeight: 600
    }
  }, !src && init);
}
Object.assign(__ds_scope, { Avatar });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data/Avatar.jsx", error: String((e && e.message) || e) }); }

// components/data/Badge.jsx
try { (() => {
const T = {
  neutral: ["var(--bg-selected)", "var(--text-secondary)"],
  accent: ["var(--accent-soft)", "var(--accent-text)"],
  red: ["var(--danger-soft)", "var(--danger)"],
  amber: ["var(--warning-soft)", "var(--warning)"],
  green: ["var(--success-soft)", "var(--success)"],
  blue: ["var(--info-soft)", "var(--info)"],
  violet: ["var(--violet-900)", "var(--violet-500)"]
};
function Badge({
  tone = "neutral",
  variant = "soft",
  children
}) {
  const [bg, fg] = T[tone];
  if (variant === "count") return /*#__PURE__*/React.createElement("span", {
    style: {
      minWidth: 18,
      height: 18,
      padding: "0 5px",
      borderRadius: 999,
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      background: bg,
      color: fg,
      font: "var(--type-label)",
      fontSize: 11
    }
  }, children);
  if (variant === "label") return /*#__PURE__*/React.createElement("span", {
    style: {
      font: "var(--type-label)",
      letterSpacing: "var(--tracking-label)",
      textTransform: "uppercase",
      color: tone === "neutral" ? "var(--text-tertiary)" : fg
    }
  }, children);
  return /*#__PURE__*/React.createElement("span", {
    style: {
      height: 20,
      padding: "0 7px",
      borderRadius: "var(--radius-xs)",
      display: "inline-flex",
      alignItems: "center",
      gap: 5,
      background: bg,
      color: fg,
      font: "var(--type-ui)",
      fontSize: 12
    }
  }, children);
}
Object.assign(__ds_scope, { Badge });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data/Badge.jsx", error: String((e && e.message) || e) }); }

// components/data/EmptyState.jsx
try { (() => {
function EmptyState({
  icon = "inbox",
  title,
  description,
  actions,
  align = "center"
}) {
  const c = align === "center";
  return /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 420,
      display: "flex",
      flexDirection: "column",
      alignItems: c ? "center" : "flex-start",
      textAlign: c ? "center" : "left",
      gap: 10
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: icon,
    size: 44,
    color: "var(--text-tertiary)",
    style: {
      marginBottom: 6
    }
  }), title && /*#__PURE__*/React.createElement("div", {
    style: {
      font: "var(--type-heading)",
      color: "var(--text-primary)"
    }
  }, title), description && /*#__PURE__*/React.createElement("div", {
    style: {
      font: "var(--type-body)",
      color: "var(--text-secondary)",
      textWrap: "pretty"
    }
  }, description), actions && /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: 8,
      marginTop: 8
    }
  }, actions));
}
Object.assign(__ds_scope, { EmptyState });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data/EmptyState.jsx", error: String((e && e.message) || e) }); }

// components/data/ListRow.jsx
try { (() => {
function ListRow({
  id,
  statusIcon = "circle",
  statusColor = "var(--text-tertiary)",
  title,
  meta,
  trailing,
  selected,
  indent = 0,
  onClick
}) {
  const [hov, setHov] = React.useState(false);
  return /*#__PURE__*/React.createElement("div", {
    onClick: onClick,
    onMouseEnter: () => setHov(true),
    onMouseLeave: () => setHov(false),
    style: {
      height: "var(--h-row)",
      display: "flex",
      alignItems: "center",
      gap: 10,
      padding: "0 16px 0 " + (16 + indent * 20) + "px",
      borderBottom: "1px solid var(--border-subtle)",
      background: selected ? "var(--bg-selected)" : hov ? "var(--bg-hover)" : "transparent",
      cursor: "pointer"
    }
  }, id && /*#__PURE__*/React.createElement("span", {
    style: {
      font: "var(--type-label)",
      color: "var(--text-tertiary)",
      width: 58,
      flexShrink: 0
    }
  }, id), /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: statusIcon,
    size: 14,
    color: statusColor
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1,
      minWidth: 0,
      font: "var(--type-ui)",
      color: "var(--text-primary)",
      overflow: "hidden",
      textOverflow: "ellipsis",
      whiteSpace: "nowrap"
    }
  }, title), meta && /*#__PURE__*/React.createElement("span", {
    style: {
      font: "var(--type-small)",
      color: "var(--text-tertiary)"
    }
  }, meta), trailing && /*#__PURE__*/React.createElement("span", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 6
    }
  }, trailing));
}
Object.assign(__ds_scope, { ListRow });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data/ListRow.jsx", error: String((e && e.message) || e) }); }

// components/data/PropertyChip.jsx
try { (() => {
function PropertyChip({
  icon,
  dot,
  label,
  empty,
  onClick
}) {
  const [hov, setHov] = React.useState(false);
  return /*#__PURE__*/React.createElement("button", {
    type: "button",
    onClick: onClick,
    onMouseEnter: () => setHov(true),
    onMouseLeave: () => setHov(false),
    style: {
      height: 24,
      padding: label ? "0 8px" : "0 6px",
      display: "inline-flex",
      alignItems: "center",
      gap: 5,
      borderRadius: "var(--radius-pill)",
      border: "1px solid var(--border-default)",
      background: hov ? "var(--bg-hover)" : "transparent",
      color: empty ? "var(--text-tertiary)" : "var(--text-primary)",
      font: "var(--type-ui)",
      fontSize: 12,
      cursor: "pointer",
      whiteSpace: "nowrap"
    }
  }, dot && /*#__PURE__*/React.createElement("span", {
    style: {
      width: 7,
      height: 7,
      borderRadius: 99,
      background: dot
    }
  }), icon && /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: icon,
    size: 13,
    color: empty ? "var(--text-tertiary)" : "var(--text-secondary)"
  }), label);
}
Object.assign(__ds_scope, { PropertyChip });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data/PropertyChip.jsx", error: String((e && e.message) || e) }); }

// components/forms/Checkbox.jsx
try { (() => {
function Checkbox({
  checked,
  onChange,
  label,
  disabled
}) {
  return /*#__PURE__*/React.createElement("label", {
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: 8,
      cursor: disabled ? "default" : "pointer",
      opacity: disabled ? 0.45 : 1,
      font: "var(--type-ui)",
      color: "var(--text-primary)"
    }
  }, /*#__PURE__*/React.createElement("span", {
    onClick: () => !disabled && onChange && onChange(!checked),
    style: {
      width: 14,
      height: 14,
      borderRadius: 4,
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      background: checked ? "var(--accent)" : "var(--bg-control)",
      border: "1px solid " + (checked ? "var(--accent)" : "var(--border-strong)"),
      color: "var(--on-accent)",
      transition: "background var(--dur-fast)"
    }
  }, checked && /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "check",
    size: 11
  })), label);
}
Object.assign(__ds_scope, { Checkbox });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Checkbox.jsx", error: String((e && e.message) || e) }); }

// components/forms/Input.jsx
try { (() => {
function Input({
  value,
  onChange,
  placeholder,
  icon,
  trailing,
  size = "md",
  invalid,
  disabled,
  style
}) {
  const [foc, setFoc] = React.useState(false);
  const h = {
    sm: 24,
    md: 28,
    lg: 32
  }[size];
  return /*#__PURE__*/React.createElement("label", {
    style: {
      height: h,
      display: "flex",
      alignItems: "center",
      gap: 6,
      padding: "0 8px",
      borderRadius: "var(--radius-sm)",
      background: "var(--bg-control)",
      border: "1px solid " + (invalid ? "var(--danger)" : foc ? "var(--accent)" : "var(--border-default)"),
      opacity: disabled ? 0.5 : 1,
      transition: "border-color var(--dur-fast)",
      ...style
    }
  }, icon && /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: icon,
    size: 14,
    color: "var(--text-tertiary)"
  }), /*#__PURE__*/React.createElement("input", {
    value: value,
    disabled: disabled,
    placeholder: placeholder,
    onChange: e => onChange && onChange(e.target.value),
    onFocus: () => setFoc(true),
    onBlur: () => setFoc(false),
    style: {
      flex: 1,
      minWidth: 0,
      border: 0,
      outline: 0,
      background: "transparent",
      color: "var(--text-primary)",
      font: "var(--type-body)"
    }
  }), trailing);
}
Object.assign(__ds_scope, { Input });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Input.jsx", error: String((e && e.message) || e) }); }

// components/forms/Switch.jsx
try { (() => {
function Switch({
  checked,
  onChange,
  disabled
}) {
  return /*#__PURE__*/React.createElement("button", {
    type: "button",
    role: "switch",
    "aria-checked": !!checked,
    disabled: disabled,
    onClick: () => onChange && onChange(!checked),
    style: {
      width: 28,
      height: 16,
      padding: 2,
      border: 0,
      borderRadius: 999,
      background: checked ? "var(--accent)" : "var(--bg-selected)",
      boxShadow: "inset 0 0 0 1px var(--border-default)",
      cursor: "pointer",
      opacity: disabled ? 0.45 : 1,
      transition: "background var(--dur-base) var(--ease-out)"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      display: "block",
      width: 12,
      height: 12,
      borderRadius: 999,
      background: checked ? "var(--on-accent)" : "var(--text-secondary)",
      transform: checked ? "translateX(12px)" : "none",
      transition: "transform var(--dur-base) var(--ease-out)"
    }
  }));
}
Object.assign(__ds_scope, { Switch });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Switch.jsx", error: String((e && e.message) || e) }); }

// components/navigation/NavItem.jsx
try { (() => {
function NavItem({
  icon,
  emoji,
  label,
  active,
  count,
  indent = 0,
  muted,
  onClick,
  trailing
}) {
  const [hov, setHov] = React.useState(false);
  return /*#__PURE__*/React.createElement("div", {
    onClick: onClick,
    onMouseEnter: () => setHov(true),
    onMouseLeave: () => setHov(false),
    style: {
      height: "var(--h-nav-item)",
      display: "flex",
      alignItems: "center",
      gap: 8,
      padding: "0 8px",
      marginLeft: indent * 16,
      borderRadius: "var(--radius-sm)",
      background: active ? "var(--bg-selected)" : hov ? "var(--bg-hover)" : "transparent",
      color: active ? "var(--text-primary)" : muted ? "var(--text-tertiary)" : "var(--text-secondary)",
      font: "var(--type-ui)",
      cursor: "pointer",
      userSelect: "none"
    }
  }, emoji ? /*#__PURE__*/React.createElement("span", {
    style: {
      width: 16,
      textAlign: "center",
      fontSize: 13
    }
  }, emoji) : icon && /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: icon,
    size: 16
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1,
      minWidth: 0,
      overflow: "hidden",
      textOverflow: "ellipsis",
      whiteSpace: "nowrap",
      fontWeight: active ? 600 : 500
    }
  }, label), hov && trailing, count != null && /*#__PURE__*/React.createElement("span", {
    style: {
      font: "var(--type-label)",
      color: "var(--text-tertiary)"
    }
  }, count));
}
Object.assign(__ds_scope, { NavItem });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/NavItem.jsx", error: String((e && e.message) || e) }); }

// components/navigation/NavSection.jsx
try { (() => {
function NavSection({
  label,
  defaultOpen = true,
  children,
  action
}) {
  const [open, setOpen] = React.useState(defaultOpen);
  const [hov, setHov] = React.useState(false);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 1
    },
    onMouseEnter: () => setHov(true),
    onMouseLeave: () => setHov(false)
  }, /*#__PURE__*/React.createElement("div", {
    onClick: () => setOpen(!open),
    style: {
      height: 26,
      display: "flex",
      alignItems: "center",
      gap: 4,
      padding: "0 8px",
      color: "var(--text-tertiary)",
      font: "var(--type-ui)",
      fontSize: 12,
      cursor: "pointer",
      userSelect: "none"
    }
  }, /*#__PURE__*/React.createElement("span", null, label), /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "chevron-right",
    size: 12,
    style: {
      transform: open ? "rotate(90deg)" : "none",
      transition: "transform var(--dur-base) var(--ease-out)",
      opacity: hov || !open ? 1 : 0
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1
    }
  }), hov && action), open && children);
}
Object.assign(__ds_scope, { NavSection });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/NavSection.jsx", error: String((e && e.message) || e) }); }

// components/navigation/Tabs.jsx
try { (() => {
function Tabs({
  items = [],
  value,
  onChange,
  variant = "pill"
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: variant === "pill" ? 4 : 16,
      borderBottom: variant === "underline" ? "1px solid var(--border-subtle)" : "none"
    }
  }, items.map(it => {
    const v = it.value ?? it,
      l = it.label ?? it,
      on = v === value;
    return variant === "pill" ? /*#__PURE__*/React.createElement("button", {
      key: v,
      type: "button",
      onClick: () => onChange && onChange(v),
      style: {
        height: 26,
        padding: "0 10px",
        border: on ? "1px solid var(--border-default)" : "1px solid transparent",
        borderRadius: "var(--radius-pill)",
        background: on ? "var(--bg-selected)" : "transparent",
        color: on ? "var(--text-primary)" : "var(--text-secondary)",
        font: "var(--type-ui)",
        fontSize: 12,
        cursor: "pointer"
      }
    }, l) : /*#__PURE__*/React.createElement("button", {
      key: v,
      type: "button",
      onClick: () => onChange && onChange(v),
      style: {
        height: 36,
        padding: 0,
        border: 0,
        borderBottom: "2px solid " + (on ? "var(--text-primary)" : "transparent"),
        marginBottom: -1,
        background: "transparent",
        color: on ? "var(--text-primary)" : "var(--text-secondary)",
        font: "var(--type-ui)",
        cursor: "pointer"
      }
    }, l);
  }));
}
Object.assign(__ds_scope, { Tabs });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/Tabs.jsx", error: String((e && e.message) || e) }); }

// components/overlays/Dialog.jsx
try { (() => {
function Dialog({
  open = true,
  title,
  onClose,
  children,
  footer,
  width = 560,
  inline
}) {
  if (!open) return null;
  const box = /*#__PURE__*/React.createElement("div", {
    role: "dialog",
    style: {
      width,
      maxWidth: "100%",
      maxHeight: "100%",
      display: "flex",
      flexDirection: "column",
      borderRadius: "var(--radius-lg)",
      background: "var(--bg-raised)",
      boxShadow: "var(--shadow-dialog)",
      overflow: "hidden"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 8,
      padding: "16px 16px 8px 20px"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      font: "var(--type-heading)",
      fontSize: 15,
      color: "var(--text-primary)"
    }
  }, title), onClose && /*#__PURE__*/React.createElement(__ds_scope.IconButton, {
    icon: "x",
    label: "Close",
    onClick: onClose
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: "8px 20px 20px",
      overflow: "auto",
      flex: 1
    }
  }, children), footer && /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      justifyContent: "flex-end",
      gap: 8,
      padding: "12px 16px",
      borderTop: "1px solid var(--border-subtle)"
    }
  }, footer));
  if (inline) return box;
  return /*#__PURE__*/React.createElement("div", {
    onClick: e => e.target === e.currentTarget && onClose && onClose(),
    style: {
      position: "fixed",
      inset: 0,
      zIndex: 50,
      background: "var(--bg-overlay)",
      display: "flex",
      alignItems: "flex-start",
      justifyContent: "center",
      padding: "10vh 24px"
    }
  }, box);
}
Object.assign(__ds_scope, { Dialog });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/overlays/Dialog.jsx", error: String((e && e.message) || e) }); }

// components/overlays/Menu.jsx
try { (() => {
function Item({
  it
}) {
  const [hov, setHov] = React.useState(false);
  return /*#__PURE__*/React.createElement("div", {
    onClick: it.onSelect,
    onMouseEnter: () => setHov(true),
    onMouseLeave: () => setHov(false),
    style: {
      height: 30,
      display: "flex",
      alignItems: "center",
      gap: 8,
      padding: "0 8px",
      borderRadius: "var(--radius-sm)",
      background: hov ? "var(--bg-selected)" : "transparent",
      color: it.danger ? "var(--danger)" : "var(--text-primary)",
      font: "var(--type-ui)",
      cursor: "pointer",
      whiteSpace: "nowrap"
    }
  }, it.icon && /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: it.icon,
    size: 15,
    color: it.danger ? "var(--danger)" : "var(--text-secondary)"
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1
    }
  }, it.label), it.kbd && /*#__PURE__*/React.createElement("span", {
    style: {
      font: "var(--type-label)",
      color: "var(--text-tertiary)"
    }
  }, it.kbd), it.checked && /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "check",
    size: 14,
    color: "var(--text-secondary)"
  }));
}
function Menu({
  items = [],
  width = 200
}) {
  return /*#__PURE__*/React.createElement("div", {
    role: "menu",
    style: {
      minWidth: width,
      padding: 4,
      borderRadius: "var(--radius-md)",
      background: "var(--bg-raised)",
      boxShadow: "var(--shadow-popover)",
      display: "flex",
      flexDirection: "column",
      gap: 1
    }
  }, items.map((it, i) => it.divider ? /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      height: 1,
      background: "var(--border-subtle)",
      margin: "4px -4px"
    }
  }) : it.heading ? /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      padding: "6px 8px 2px",
      font: "var(--type-small)",
      color: "var(--text-tertiary)"
    }
  }, it.heading) : /*#__PURE__*/React.createElement(Item, {
    key: i,
    it: it
  })));
}
Object.assign(__ds_scope, { Menu });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/overlays/Menu.jsx", error: String((e && e.message) || e) }); }

// components/forms/Select.jsx
try { (() => {
function Select({
  value,
  options = [],
  onChange,
  variant = "plain",
  style
}) {
  const [open, setOpen] = React.useState(false);
  const [hov, setHov] = React.useState(false);
  const cur = options.find(o => (o.value ?? o) === value);
  const label = cur ? cur.label ?? cur : value;
  return /*#__PURE__*/React.createElement("span", {
    style: {
      position: "relative",
      display: "inline-flex",
      ...style
    }
  }, /*#__PURE__*/React.createElement("button", {
    type: "button",
    onClick: () => setOpen(!open),
    onMouseEnter: () => setHov(true),
    onMouseLeave: () => setHov(false),
    style: {
      height: 28,
      padding: "0 8px",
      display: "inline-flex",
      alignItems: "center",
      gap: 6,
      borderRadius: "var(--radius-sm)",
      border: variant === "boxed" ? "1px solid var(--border-default)" : "1px solid transparent",
      background: hov || open ? "var(--bg-hover)" : variant === "boxed" ? "var(--bg-control)" : "transparent",
      color: "var(--text-primary)",
      font: "var(--type-ui)",
      cursor: "pointer"
    }
  }, label, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "chevron-down",
    size: 14,
    color: "var(--text-tertiary)"
  })), open && /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      top: 32,
      right: 0,
      zIndex: 20
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Menu, {
    items: options.map(o => ({
      label: o.label ?? o,
      checked: (o.value ?? o) === value,
      onSelect: () => {
        onChange && onChange(o.value ?? o);
        setOpen(false);
      }
    }))
  })));
}
Object.assign(__ds_scope, { Select });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Select.jsx", error: String((e && e.message) || e) }); }

// components/overlays/Tooltip.jsx
try { (() => {
function Tooltip({
  label,
  kbd,
  children,
  side = "bottom",
  forceOpen
}) {
  const [hov, setHov] = React.useState(false);
  const show = forceOpen || hov;
  return /*#__PURE__*/React.createElement("span", {
    style: {
      position: "relative",
      display: "inline-flex"
    },
    onMouseEnter: () => setHov(true),
    onMouseLeave: () => setHov(false)
  }, children, show && /*#__PURE__*/React.createElement("span", {
    role: "tooltip",
    style: {
      position: "absolute",
      left: "50%",
      transform: "translateX(-50%)",
      [side === "top" ? "bottom" : "top"]: "calc(100% + 6px)",
      zIndex: 30,
      height: 24,
      padding: "0 8px",
      display: "inline-flex",
      alignItems: "center",
      gap: 6,
      whiteSpace: "nowrap",
      borderRadius: "var(--radius-sm)",
      background: "var(--bg-raised)",
      boxShadow: "var(--shadow-popover)",
      color: "var(--text-primary)",
      font: "var(--type-small)"
    }
  }, label, kbd && /*#__PURE__*/React.createElement("span", {
    style: {
      font: "var(--type-label)",
      color: "var(--text-tertiary)"
    }
  }, kbd)));
}
Object.assign(__ds_scope, { Tooltip });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/overlays/Tooltip.jsx", error: String((e && e.message) || e) }); }

// ui_kits/app/CreateDialog.jsx
try { (() => {
const {
  Dialog: D5,
  Button: B5,
  PropertyChip: PC5,
  Switch: S5
} = window.KestrelDesignSystem_3eefff;
function CreateDialog({
  open,
  onClose,
  onCreate
}) {
  const [title, setTitle] = React.useState("");
  const [more, setMore] = React.useState(false);
  if (!open) return null;
  const inp = {
    width: "100%",
    border: 0,
    outline: 0,
    background: "transparent",
    color: "var(--text-primary)",
    padding: 0
  };
  return /*#__PURE__*/React.createElement(D5, {
    width: 680,
    onClose: onClose,
    title: /*#__PURE__*/React.createElement("span", {
      style: {
        display: "flex",
        alignItems: "center",
        gap: 6,
        fontSize: 13
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        color: "var(--text-secondary)",
        fontWeight: 500
      }
    }, "Platform"), /*#__PURE__*/React.createElement("span", {
      style: {
        color: "var(--text-tertiary)"
      }
    }, "\u203A"), "New issue"),
    footer: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("span", {
      style: {
        display: "flex",
        alignItems: "center",
        gap: 8,
        font: "var(--type-small)",
        color: "var(--text-secondary)",
        marginRight: "auto"
      }
    }, /*#__PURE__*/React.createElement(S5, {
      checked: more,
      onChange: setMore
    }), "Create more"), /*#__PURE__*/React.createElement(B5, {
      onClick: onClose
    }, "Cancel"), /*#__PURE__*/React.createElement(B5, {
      variant: "primary",
      disabled: !title,
      onClick: () => {
        onCreate(title);
        setTitle("");
        if (!more) onClose();
      }
    }, "Create issue"))
  }, /*#__PURE__*/React.createElement("input", {
    autoFocus: true,
    value: title,
    onChange: e => setTitle(e.target.value),
    placeholder: "Issue title",
    style: {
      ...inp,
      font: "var(--type-title)",
      marginBottom: 8
    }
  }), /*#__PURE__*/React.createElement("textarea", {
    placeholder: "Add a description\u2026",
    rows: 4,
    style: {
      ...inp,
      font: "var(--type-body)",
      resize: "none"
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexWrap: "wrap",
      gap: 6,
      marginTop: 12
    }
  }, /*#__PURE__*/React.createElement(PC5, {
    icon: "circle-dashed",
    label: "Backlog"
  }), /*#__PURE__*/React.createElement(PC5, {
    icon: "ellipsis",
    label: "No priority",
    empty: true
  }), /*#__PURE__*/React.createElement(PC5, {
    icon: "user",
    label: "Assignee",
    empty: true
  }), /*#__PURE__*/React.createElement(PC5, {
    icon: "tag",
    label: "Labels",
    empty: true
  }), /*#__PURE__*/React.createElement(PC5, {
    icon: "calendar",
    label: "Due date",
    empty: true
  })));
}
window.CreateDialog = CreateDialog;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/app/CreateDialog.jsx", error: String((e && e.message) || e) }); }

// ui_kits/app/InboxView.jsx
try { (() => {
const {
  EmptyState: ES1,
  Avatar: Av3,
  IconButton: IB3,
  Badge: Bd3,
  PropertyChip: PC3
} = window.KestrelDesignSystem_3eefff;
function InboxRow({
  n,
  active,
  onClick
}) {
  const [h, setH] = React.useState(false);
  return /*#__PURE__*/React.createElement("div", {
    onClick: onClick,
    onMouseEnter: () => setH(true),
    onMouseLeave: () => setH(false),
    style: {
      display: "flex",
      gap: 10,
      padding: "10px 12px",
      margin: "0 6px",
      borderRadius: 6,
      background: active ? "var(--bg-selected)" : h ? "var(--bg-hover)" : "transparent",
      cursor: "pointer"
    }
  }, /*#__PURE__*/React.createElement(Av3, {
    name: n.who,
    size: 28,
    color: "var(--gray-6)"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      font: "var(--type-ui)",
      color: n.unread ? "var(--text-primary)" : "var(--text-secondary)",
      whiteSpace: "nowrap",
      overflow: "hidden",
      textOverflow: "ellipsis"
    }
  }, n.title), /*#__PURE__*/React.createElement("div", {
    style: {
      font: "var(--type-small)",
      color: "var(--text-tertiary)",
      whiteSpace: "nowrap",
      overflow: "hidden",
      textOverflow: "ellipsis"
    }
  }, n.body)), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      alignItems: "flex-end",
      gap: 6
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      font: "var(--type-small)",
      color: "var(--text-tertiary)"
    }
  }, n.time), n.unread && /*#__PURE__*/React.createElement("span", {
    style: {
      width: 6,
      height: 6,
      borderRadius: 9,
      background: "var(--accent)"
    }
  })));
}
function InboxView() {
  const [sel, setSel] = React.useState(null);
  const cur = window.KES_INBOX.find(n => n.id === sel);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      height: "100%"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: "var(--w-list-pane)",
      borderRight: "1px solid var(--border-subtle)",
      display: "flex",
      flexDirection: "column"
    }
  }, /*#__PURE__*/React.createElement(PanelHeader, {
    title: "Inbox",
    actions: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(IB3, {
      icon: "check-check",
      label: "Mark all read"
    }), /*#__PURE__*/React.createElement(IB3, {
      icon: "list-filter",
      label: "Filter"
    }), /*#__PURE__*/React.createElement(IB3, {
      icon: "sliders-horizontal",
      label: "Display"
    }))
  }, /*#__PURE__*/React.createElement(IB3, {
    icon: "ellipsis",
    size: "sm",
    label: "More"
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      paddingTop: 6,
      display: "flex",
      flexDirection: "column",
      gap: 1
    }
  }, window.KES_INBOX.map(n => /*#__PURE__*/React.createElement(InboxRow, {
    key: n.id,
    n: n,
    active: sel === n.id,
    onClick: () => setSel(n.id)
  })))), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      display: "flex",
      alignItems: cur ? "stretch" : "center",
      justifyContent: "center"
    }
  }, cur ? /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      padding: "28px 40px",
      display: "flex",
      flexDirection: "column",
      gap: 14
    }
  }, /*#__PURE__*/React.createElement(Bd3, {
    variant: "label"
  }, cur.title.split(" ")[0]), /*#__PURE__*/React.createElement("div", {
    style: {
      font: "var(--type-title)"
    }
  }, cur.title.split(" ").slice(1).join(" ")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: 6
    }
  }, /*#__PURE__*/React.createElement(PC3, {
    icon: "circle-dot",
    label: "In progress"
  }), /*#__PURE__*/React.createElement(PC3, {
    icon: "signal-medium",
    label: "Medium"
  }), /*#__PURE__*/React.createElement(PC3, {
    icon: "user",
    label: cur.who
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      font: "var(--type-body)",
      color: "var(--text-secondary)"
    }
  }, cur.body)) : /*#__PURE__*/React.createElement(ES1, {
    icon: "inbox",
    description: "No notification selected"
  })));
}
window.InboxView = InboxView;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/app/InboxView.jsx", error: String((e && e.message) || e) }); }

// ui_kits/app/IssuesView.jsx
try { (() => {
const {
  ListRow,
  PropertyChip,
  Avatar: _Av,
  Tabs,
  IconButton: IB2,
  Button: Btn2,
  Badge
} = window.KestrelDesignSystem_3eefff;
function IssuesView({
  onOpen,
  onCompose
}) {
  const [tab, setTab] = React.useState("All issues");
  const [sel, setSel] = React.useState(null);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      height: "100%"
    }
  }, /*#__PURE__*/React.createElement(PanelHeader, {
    icon: "copy",
    title: "Issues",
    count: 7,
    actions: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(IB2, {
      icon: "list-filter",
      label: "Filter"
    }), /*#__PURE__*/React.createElement(IB2, {
      icon: "sliders-horizontal",
      label: "Display"
    }), /*#__PURE__*/React.createElement(Btn2, {
      size: "sm",
      variant: "primary",
      icon: "plus",
      onClick: onCompose
    }, "New issue"))
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: "8px 12px",
      borderBottom: "1px solid var(--border-subtle)"
    }
  }, /*#__PURE__*/React.createElement(Tabs, {
    items: ["All issues", "Active", "Backlog"],
    value: tab,
    onChange: setTab
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      overflow: "auto"
    }
  }, window.KES_ISSUES.filter(g => tab === "All issues" || (tab === "Backlog" ? g.group === "Backlog" : g.group !== "Backlog")).map(g => /*#__PURE__*/React.createElement("div", {
    key: g.group
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      height: 34,
      display: "flex",
      alignItems: "center",
      gap: 8,
      padding: "0 16px",
      background: "var(--bg-hover)",
      borderBottom: "1px solid var(--border-subtle)"
    }
  }, /*#__PURE__*/React.createElement(Badge, {
    variant: "label"
  }, g.group), /*#__PURE__*/React.createElement("span", {
    style: {
      font: "var(--type-label)",
      color: "var(--text-tertiary)"
    }
  }, g.items.length)), g.items.map(it => /*#__PURE__*/React.createElement(ListRow, {
    key: it.id,
    id: it.id,
    statusIcon: g.icon,
    statusColor: g.color,
    title: it.title,
    selected: sel === it.id,
    indent: it.sub || 0,
    onClick: () => {
      setSel(it.id);
      onOpen && onOpen(it);
    },
    trailing: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(PropertyChip, {
      dot: it.label[1],
      label: it.label[0]
    }), it.due && /*#__PURE__*/React.createElement(PropertyChip, {
      icon: "calendar",
      label: it.due
    }), /*#__PURE__*/React.createElement(_Av, {
      name: it.who,
      size: 20,
      color: "var(--gray-6)"
    }))
  }))))));
}
window.IssuesView = IssuesView;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/app/IssuesView.jsx", error: String((e && e.message) || e) }); }

// ui_kits/app/PanelHeader.jsx
try { (() => {
const {
  IconButton: _IB,
  Icon: _Ic
} = window.KestrelDesignSystem_3eefff;
function PanelHeader({
  icon,
  title,
  count,
  actions,
  children
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      height: "var(--h-header)",
      flexShrink: 0,
      display: "flex",
      alignItems: "center",
      gap: 8,
      padding: "0 12px 0 16px",
      borderBottom: "1px solid var(--border-subtle)"
    }
  }, icon && /*#__PURE__*/React.createElement(_Ic, {
    name: icon,
    size: 16,
    color: "var(--text-secondary)"
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      font: "var(--type-ui)",
      fontWeight: 600
    }
  }, title), count != null && /*#__PURE__*/React.createElement("span", {
    style: {
      font: "var(--type-label)",
      color: "var(--text-tertiary)"
    }
  }, count), children, /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1
    }
  }), actions);
}
window.PanelHeader = PanelHeader;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/app/PanelHeader.jsx", error: String((e && e.message) || e) }); }

// ui_kits/app/ProjectsView.jsx
try { (() => {
const {
  EmptyState: ES2,
  Button: B4,
  Tabs: T4,
  IconButton: IB4
} = window.KestrelDesignSystem_3eefff;
function ProjectsView({
  onCompose
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      height: "100%"
    }
  }, /*#__PURE__*/React.createElement(PanelHeader, {
    title: "Projects",
    actions: /*#__PURE__*/React.createElement(B4, {
      variant: "ghost",
      size: "sm",
      icon: "plus",
      onClick: onCompose
    }, "New project")
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      padding: "8px 12px"
    }
  }, /*#__PURE__*/React.createElement(T4, {
    items: ["All projects"],
    value: "All projects"
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1
    }
  }), /*#__PURE__*/React.createElement(IB4, {
    icon: "list-filter",
    label: "Filter"
  }), /*#__PURE__*/React.createElement(IB4, {
    icon: "sliders-horizontal",
    label: "Display"
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      display: "flex",
      alignItems: "center",
      justifyContent: "center"
    }
  }, /*#__PURE__*/React.createElement(ES2, {
    icon: "boxes",
    align: "left",
    title: "Projects",
    description: "Projects are larger units of work with one clear outcome, like a feature you want to ship. They can span teams and hold issues and documents.",
    actions: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(B4, {
      variant: "primary",
      kbd: ["N", "P"],
      onClick: onCompose
    }, "Create project"), /*#__PURE__*/React.createElement(B4, null, "Documentation"))
  })));
}
window.ProjectsView = ProjectsView;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/app/ProjectsView.jsx", error: String((e && e.message) || e) }); }

// ui_kits/app/Sidebar.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const {
  NavItem,
  NavSection,
  IconButton,
  Avatar,
  Icon
} = window.KestrelDesignSystem_3eefff;
function Sidebar({
  page,
  setPage,
  onCompose
}) {
  const n = (id, icon, label, x) => /*#__PURE__*/React.createElement(NavItem, _extends({
    icon: icon,
    label: label,
    active: page === id,
    onClick: () => setPage(id)
  }, x));
  return /*#__PURE__*/React.createElement("aside", {
    style: {
      width: "var(--w-sidebar)",
      flexShrink: 0,
      display: "flex",
      flexDirection: "column",
      gap: 14,
      padding: "10px 8px"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 6,
      padding: "0 4px"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 8,
      flex: 1,
      minWidth: 0,
      font: "var(--type-ui)",
      fontWeight: 600
    }
  }, /*#__PURE__*/React.createElement(Avatar, {
    name: "Northwind",
    square: true,
    size: 20,
    color: "var(--gray-6)"
  }), "Northwind", /*#__PURE__*/React.createElement(Icon, {
    name: "chevron-down",
    size: 14,
    color: "var(--text-tertiary)"
  })), /*#__PURE__*/React.createElement(IconButton, {
    icon: "search",
    label: "Search"
  }), /*#__PURE__*/React.createElement(IconButton, {
    icon: "square-pen",
    variant: "round",
    label: "New issue",
    onClick: onCompose
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 1
    }
  }, n("inbox", "inbox", "Inbox", {
    count: 2
  }), n("mine", "scan-eye", "My issues"), n("issues", "copy", "Issues")), /*#__PURE__*/React.createElement(NavSection, {
    label: "Workspace"
  }, n("projects", "box", "Projects"), n("views", "layers", "Views"), /*#__PURE__*/React.createElement(NavItem, {
    icon: "ellipsis",
    label: "More"
  })), /*#__PURE__*/React.createElement(NavSection, {
    label: "Your teams",
    action: /*#__PURE__*/React.createElement(IconButton, {
      icon: "plus",
      size: "sm",
      label: "Add team"
    })
  }, /*#__PURE__*/React.createElement(NavItem, {
    emoji: "\uD83D\uDEE0",
    label: "Platform"
  }), /*#__PURE__*/React.createElement(NavItem, {
    icon: "house",
    label: "Home",
    indent: 1
  }), /*#__PURE__*/React.createElement(NavItem, {
    icon: "copy",
    label: "Issues",
    indent: 1
  }), /*#__PURE__*/React.createElement(NavItem, {
    icon: "box",
    label: "Projects",
    indent: 1
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      justifyContent: "space-between",
      padding: "0 4px"
    }
  }, /*#__PURE__*/React.createElement(IconButton, {
    icon: "circle-help",
    variant: "round",
    label: "Help"
  }), /*#__PURE__*/React.createElement(Avatar, {
    name: "Max Mann",
    size: 22
  })));
}
window.Sidebar = Sidebar;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/app/Sidebar.jsx", error: String((e && e.message) || e) }); }

// ui_kits/app/data.js
try { (() => {
window.KES_ISSUES = [{
  group: "In progress",
  icon: "circle-dot",
  color: "var(--warning)",
  items: [{
    id: "KES-128",
    title: "Keyboard navigation for list views",
    label: ["Accessibility", "var(--blue-500)"],
    due: "14 Oct",
    who: "Max Mann"
  }, {
    id: "KES-121",
    title: "Inline status picker in rows",
    label: ["Editor", "var(--green-500)"],
    due: "18 Oct",
    who: "Ana Ruiz"
  }]
}, {
  group: "Todo",
  icon: "circle",
  color: "var(--text-tertiary)",
  items: [{
    id: "KES-117",
    title: "Empty state copy for Views",
    label: ["Design", "var(--violet-500)"],
    due: "22 Oct",
    who: "Max Mann"
  }, {
    id: "KES-112",
    title: "Bulk edit labels from selection",
    label: ["Enhancement", "var(--violet-500)"],
    due: "29 Oct",
    who: "Lee Park"
  }, {
    id: "KES-109",
    title: "Sync assignee changes from GitHub",
    label: ["Integrations", "var(--amber-500)"],
    due: "03 Nov",
    who: "Ana Ruiz",
    sub: 1
  }]
}, {
  group: "Backlog",
  icon: "circle-dashed",
  color: "var(--text-tertiary)",
  items: [{
    id: "KES-96",
    title: "Saved filters per team",
    label: ["Enhancement", "var(--violet-500)"],
    who: "Lee Park"
  }, {
    id: "KES-88",
    title: "Crash when pasting a table into description",
    label: ["Bug", "var(--red-500)"],
    who: "Max Mann"
  }]
}];
window.KES_INBOX = [{
  id: 1,
  who: "Ana Ruiz",
  title: "KES-121 Inline status picker in rows",
  body: "Ana moved this to In progress",
  time: "12m",
  unread: true
}, {
  id: 2,
  who: "Lee Park",
  title: "KES-112 Bulk edit labels",
  body: "Lee: Can we reuse the label menu here?",
  time: "1h",
  unread: true
}, {
  id: 3,
  who: "Max Mann",
  title: "Welcome to Northwind",
  body: "Start with the keyboard shortcuts guide",
  time: "4h"
}];
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/app/data.js", error: String((e && e.message) || e) }); }

__ds_ns.Button = __ds_scope.Button;

__ds_ns.IconButton = __ds_scope.IconButton;

__ds_ns.Kbd = __ds_scope.Kbd;

__ds_ns.Icon = __ds_scope.Icon;

__ds_ns.Avatar = __ds_scope.Avatar;

__ds_ns.Badge = __ds_scope.Badge;

__ds_ns.EmptyState = __ds_scope.EmptyState;

__ds_ns.ListRow = __ds_scope.ListRow;

__ds_ns.PropertyChip = __ds_scope.PropertyChip;

__ds_ns.Checkbox = __ds_scope.Checkbox;

__ds_ns.Input = __ds_scope.Input;

__ds_ns.Select = __ds_scope.Select;

__ds_ns.Switch = __ds_scope.Switch;

__ds_ns.NavItem = __ds_scope.NavItem;

__ds_ns.NavSection = __ds_scope.NavSection;

__ds_ns.Tabs = __ds_scope.Tabs;

__ds_ns.Dialog = __ds_scope.Dialog;

__ds_ns.Menu = __ds_scope.Menu;

__ds_ns.Tooltip = __ds_scope.Tooltip;

})();
