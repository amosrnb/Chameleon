# Kestrel app UI kit
Click-through of the core workspace: sidebar, Issues list (grouped by status), Inbox (list + detail), Projects (empty state), Create issue dialog (press **C** or the compose button).
Composes components from the bundle (`window.KestrelDesignSystem_3eefff`). Product-specific pieces: `Sidebar.jsx`, `PanelHeader.jsx`, `IssuesView.jsx`, `InboxView.jsx`, `ProjectsView.jsx`, `CreateDialog.jsx`; sample data in `data.js`.
Layout: 232px sidebar on `--bg-app`, content on an inset `--bg-panel` with 8px gutter and 8px radius.
