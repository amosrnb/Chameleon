const { ListRow, PropertyChip, Avatar: _Av, Tabs, IconButton: IB2, Button: Btn2, Badge } = window.KestrelDesignSystem_3eefff;
function IssuesView({ onOpen, onCompose }) {
  const [tab, setTab] = React.useState("All issues");
  const [sel, setSel] = React.useState(null);
  return (
    <div style={{ display: "flex", flexDirection: "column", height: "100%" }}>
      <PanelHeader icon="copy" title="Issues" count={7} actions={<><IB2 icon="list-filter" label="Filter" /><IB2 icon="sliders-horizontal" label="Display" /><Btn2 size="sm" variant="primary" icon="plus" onClick={onCompose}>New issue</Btn2></>} />
      <div style={{ padding: "8px 12px", borderBottom: "1px solid var(--border-subtle)" }}><Tabs items={["All issues", "Active", "Backlog"]} value={tab} onChange={setTab} /></div>
      <div style={{ flex: 1, overflow: "auto" }}>
        {window.KES_ISSUES.filter(g => tab === "All issues" || (tab === "Backlog" ? g.group === "Backlog" : g.group !== "Backlog")).map(g => (
          <div key={g.group}>
            <div style={{ height: 34, display: "flex", alignItems: "center", gap: 8, padding: "0 16px", background: "var(--bg-hover)", borderBottom: "1px solid var(--border-subtle)" }}>
              <Badge variant="label">{g.group}</Badge><span style={{ font: "var(--type-label)", color: "var(--text-tertiary)" }}>{g.items.length}</span>
            </div>
            {g.items.map(it => (
              <ListRow key={it.id} id={it.id} statusIcon={g.icon} statusColor={g.color} title={it.title} selected={sel === it.id} indent={it.sub || 0}
                onClick={() => { setSel(it.id); onOpen && onOpen(it); }}
                trailing={<><PropertyChip dot={it.label[1]} label={it.label[0]} />{it.due && <PropertyChip icon="calendar" label={it.due} />}<_Av name={it.who} size={20} color="var(--gray-6)" /></>} />
            ))}
          </div>
        ))}
      </div>
    </div>
  );
}
window.IssuesView = IssuesView;
