const { NavItem, NavSection, IconButton, Avatar, Icon } = window.KestrelDesignSystem_3eefff;
function Sidebar({ page, setPage, onCompose }) {
  const n = (id, icon, label, x) => <NavItem icon={icon} label={label} active={page === id} onClick={() => setPage(id)} {...x} />;
  return (
    <aside style={{ width: "var(--w-sidebar)", flexShrink: 0, display: "flex", flexDirection: "column", gap: 14, padding: "10px 8px" }}>
      <div style={{ display: "flex", alignItems: "center", gap: 6, padding: "0 4px" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 8, flex: 1, minWidth: 0, font: "var(--type-ui)", fontWeight: 600 }}>
          <Avatar name="Northwind" square size={20} color="var(--gray-6)" />Northwind<Icon name="chevron-down" size={14} color="var(--text-tertiary)" />
        </div>
        <IconButton icon="search" label="Search" />
        <IconButton icon="square-pen" variant="round" label="New issue" onClick={onCompose} />
      </div>
      <div style={{ display: "flex", flexDirection: "column", gap: 1 }}>
        {n("inbox", "inbox", "Inbox", { count: 2 })}{n("mine", "scan-eye", "My issues")}{n("issues", "copy", "Issues")}
      </div>
      <NavSection label="Workspace">{n("projects", "box", "Projects")}{n("views", "layers", "Views")}<NavItem icon="ellipsis" label="More" /></NavSection>
      <NavSection label="Your teams" action={<IconButton icon="plus" size="sm" label="Add team" />}>
        <NavItem emoji="🛠" label="Platform" /><NavItem icon="house" label="Home" indent={1} /><NavItem icon="copy" label="Issues" indent={1} /><NavItem icon="box" label="Projects" indent={1} />
      </NavSection>
      <div style={{ flex: 1 }} />
      <div style={{ display: "flex", justifyContent: "space-between", padding: "0 4px" }}><IconButton icon="circle-help" variant="round" label="Help" /><Avatar name="Max Mann" size={22} /></div>
    </aside>
  );
}
window.Sidebar = Sidebar;
