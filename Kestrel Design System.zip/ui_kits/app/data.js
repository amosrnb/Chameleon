window.KES_ISSUES = [
 { group: "In progress", icon: "circle-dot", color: "var(--warning)", items: [
  { id: "KES-128", title: "Keyboard navigation for list views", label: ["Accessibility", "var(--blue-500)"], due: "14 Oct", who: "Max Mann" },
  { id: "KES-121", title: "Inline status picker in rows", label: ["Editor", "var(--green-500)"], due: "18 Oct", who: "Ana Ruiz" } ] },
 { group: "Todo", icon: "circle", color: "var(--text-tertiary)", items: [
  { id: "KES-117", title: "Empty state copy for Views", label: ["Design", "var(--violet-500)"], due: "22 Oct", who: "Max Mann" },
  { id: "KES-112", title: "Bulk edit labels from selection", label: ["Enhancement", "var(--violet-500)"], due: "29 Oct", who: "Lee Park" },
  { id: "KES-109", title: "Sync assignee changes from GitHub", label: ["Integrations", "var(--amber-500)"], due: "03 Nov", who: "Ana Ruiz", sub: 1 } ] },
 { group: "Backlog", icon: "circle-dashed", color: "var(--text-tertiary)", items: [
  { id: "KES-96", title: "Saved filters per team", label: ["Enhancement", "var(--violet-500)"], who: "Lee Park" },
  { id: "KES-88", title: "Crash when pasting a table into description", label: ["Bug", "var(--red-500)"], who: "Max Mann" } ] } ];
window.KES_INBOX = [
 { id: 1, who: "Ana Ruiz", title: "KES-121 Inline status picker in rows", body: "Ana moved this to In progress", time: "12m", unread: true },
 { id: 2, who: "Lee Park", title: "KES-112 Bulk edit labels", body: "Lee: Can we reuse the label menu here?", time: "1h", unread: true },
 { id: 3, who: "Max Mann", title: "Welcome to Northwind", body: "Start with the keyboard shortcuts guide", time: "4h" } ];
