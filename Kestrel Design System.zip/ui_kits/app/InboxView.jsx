const { EmptyState: ES1, Avatar: Av3, IconButton: IB3, Badge: Bd3, PropertyChip: PC3 } = window.KestrelDesignSystem_3eefff;
function InboxRow({ n, active, onClick }) {
  const [h, setH] = React.useState(false);
  return (
    <div onClick={onClick} onMouseEnter={() => setH(true)} onMouseLeave={() => setH(false)} style={{ display: "flex", gap: 10, padding: "10px 12px", margin: "0 6px", borderRadius: 6, background: active ? "var(--bg-selected)" : h ? "var(--bg-hover)" : "transparent", cursor: "pointer" }}>
      <Av3 name={n.who} size={28} color="var(--gray-6)" />
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ font: "var(--type-ui)", color: n.unread ? "var(--text-primary)" : "var(--text-secondary)", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{n.title}</div>
        <div style={{ font: "var(--type-small)", color: "var(--text-tertiary)", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{n.body}</div>
      </div>
      <div style={{ display: "flex", flexDirection: "column", alignItems: "flex-end", gap: 6 }}><span style={{ font: "var(--type-small)", color: "var(--text-tertiary)" }}>{n.time}</span>{n.unread && <span style={{ width: 6, height: 6, borderRadius: 9, background: "var(--accent)" }} />}</div>
    </div>
  );
}
function InboxView() {
  const [sel, setSel] = React.useState(null);
  const cur = window.KES_INBOX.find(n => n.id === sel);
  return (
    <div style={{ display: "flex", height: "100%" }}>
      <div style={{ width: "var(--w-list-pane)", borderRight: "1px solid var(--border-subtle)", display: "flex", flexDirection: "column" }}>
        <PanelHeader title="Inbox" actions={<><IB3 icon="check-check" label="Mark all read" /><IB3 icon="list-filter" label="Filter" /><IB3 icon="sliders-horizontal" label="Display" /></>}><IB3 icon="ellipsis" size="sm" label="More" /></PanelHeader>
        <div style={{ paddingTop: 6, display: "flex", flexDirection: "column", gap: 1 }}>{window.KES_INBOX.map(n => <InboxRow key={n.id} n={n} active={sel === n.id} onClick={() => setSel(n.id)} />)}</div>
      </div>
      <div style={{ flex: 1, display: "flex", alignItems: cur ? "stretch" : "center", justifyContent: "center" }}>
        {cur ? (
          <div style={{ flex: 1, padding: "28px 40px", display: "flex", flexDirection: "column", gap: 14 }}>
            <Bd3 variant="label">{cur.title.split(" ")[0]}</Bd3>
            <div style={{ font: "var(--type-title)" }}>{cur.title.split(" ").slice(1).join(" ")}</div>
            <div style={{ display: "flex", gap: 6 }}><PC3 icon="circle-dot" label="In progress" /><PC3 icon="signal-medium" label="Medium" /><PC3 icon="user" label={cur.who} /></div>
            <div style={{ font: "var(--type-body)", color: "var(--text-secondary)" }}>{cur.body}</div>
          </div>
        ) : <ES1 icon="inbox" description="No notification selected" />}
      </div>
    </div>
  );
}
window.InboxView = InboxView;
