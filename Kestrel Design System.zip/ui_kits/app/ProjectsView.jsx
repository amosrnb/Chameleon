const { EmptyState: ES2, Button: B4, Tabs: T4, IconButton: IB4 } = window.KestrelDesignSystem_3eefff;
function ProjectsView({ onCompose }) {
  return (
    <div style={{ display: "flex", flexDirection: "column", height: "100%" }}>
      <PanelHeader title="Projects" actions={<B4 variant="ghost" size="sm" icon="plus" onClick={onCompose}>New project</B4>} />
      <div style={{ display: "flex", alignItems: "center", padding: "8px 12px" }}><T4 items={["All projects"]} value="All projects" /><span style={{ flex: 1 }} /><IB4 icon="list-filter" label="Filter" /><IB4 icon="sliders-horizontal" label="Display" /></div>
      <div style={{ flex: 1, display: "flex", alignItems: "center", justifyContent: "center" }}>
        <ES2 icon="boxes" align="left" title="Projects" description="Projects are larger units of work with one clear outcome, like a feature you want to ship. They can span teams and hold issues and documents."
          actions={<><B4 variant="primary" kbd={["N", "P"]} onClick={onCompose}>Create project</B4><B4>Documentation</B4></>} />
      </div>
    </div>
  );
}
window.ProjectsView = ProjectsView;
