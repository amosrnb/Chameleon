const { Dialog: D5, Button: B5, PropertyChip: PC5, Switch: S5 } = window.KestrelDesignSystem_3eefff;
function CreateDialog({ open, onClose, onCreate }) {
  const [title, setTitle] = React.useState("");
  const [more, setMore] = React.useState(false);
  if (!open) return null;
  const inp = { width: "100%", border: 0, outline: 0, background: "transparent", color: "var(--text-primary)", padding: 0 };
  return (
    <D5 width={680} onClose={onClose} title={<span style={{ display: "flex", alignItems: "center", gap: 6, fontSize: 13 }}><span style={{ color: "var(--text-secondary)", fontWeight: 500 }}>Platform</span><span style={{ color: "var(--text-tertiary)" }}>›</span>New issue</span>}
      footer={<><span style={{ display: "flex", alignItems: "center", gap: 8, font: "var(--type-small)", color: "var(--text-secondary)", marginRight: "auto" }}><S5 checked={more} onChange={setMore} />Create more</span><B5 onClick={onClose}>Cancel</B5><B5 variant="primary" disabled={!title} onClick={() => { onCreate(title); setTitle(""); if (!more) onClose(); }}>Create issue</B5></>}>
      <input autoFocus value={title} onChange={e => setTitle(e.target.value)} placeholder="Issue title" style={{ ...inp, font: "var(--type-title)", marginBottom: 8 }} />
      <textarea placeholder="Add a description…" rows={4} style={{ ...inp, font: "var(--type-body)", resize: "none" }} />
      <div style={{ display: "flex", flexWrap: "wrap", gap: 6, marginTop: 12 }}>
        <PC5 icon="circle-dashed" label="Backlog" /><PC5 icon="ellipsis" label="No priority" empty /><PC5 icon="user" label="Assignee" empty /><PC5 icon="tag" label="Labels" empty /><PC5 icon="calendar" label="Due date" empty />
      </div>
    </D5>
  );
}
window.CreateDialog = CreateDialog;
