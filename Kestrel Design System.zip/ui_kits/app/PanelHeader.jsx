const { IconButton: _IB, Icon: _Ic } = window.KestrelDesignSystem_3eefff;
function PanelHeader({ icon, title, count, actions, children }) {
  return (
    <div style={{ height: "var(--h-header)", flexShrink: 0, display: "flex", alignItems: "center", gap: 8, padding: "0 12px 0 16px", borderBottom: "1px solid var(--border-subtle)" }}>
      {icon && <_Ic name={icon} size={16} color="var(--text-secondary)" />}
      <span style={{ font: "var(--type-ui)", fontWeight: 600 }}>{title}</span>
      {count != null && <span style={{ font: "var(--type-label)", color: "var(--text-tertiary)" }}>{count}</span>}
      {children}
      <span style={{ flex: 1 }} />
      {actions}
    </div>
  );
}
window.PanelHeader = PanelHeader;
